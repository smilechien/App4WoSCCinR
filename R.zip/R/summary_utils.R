# R/summary_utils.R
# Utilities for Summary Report (citations + h-index)

detect_cite_col <- function(df){
  candidates <- c(
    "Times.Cited..WoS.Core","Times Cited","Times.Cited","TC",
    "times_cited","timescited",
    "citation","Citation"
  )
  candidates <- candidates[candidates %in% names(df)]
  if (!length(candidates)) return(NA_character_)

  best <- candidates[1]
  best_max <- -Inf
  for (cc in candidates){
    x <- suppressWarnings(as.numeric(df[[cc]]))
    m <- suppressWarnings(max(x, na.rm = TRUE))
    if (is.finite(m) && m > best_max){
      best <- cc; best_max <- m
    }
  }
  best
}

h_index <- function(x){
  x <- suppressWarnings(as.numeric(x))
  x <- x[is.finite(x)]
  if (!length(x)) return(0L)
  x <- sort(x, decreasing = TRUE)
  sum(x >= seq_along(x))
}
