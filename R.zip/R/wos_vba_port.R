# R/wos_vba_port.R
# ------------------------------------------------------------
# VBA-style WoS routines (strict, no "optimization"):
# - Routine 1: wosauthor.xls/.xlsx -> woswide32 (fixed 32 columns, your header order)
# - Routine 2/3: woswide32 -> woslong32 (fill FA/CA metadata from Addresses/Reprint)
#
# Key rules (per excelvbadataWoS.txt guidance):
# - FA/CA use FULL NAMES for FAauthor/Caauthor when possible.
# - If Reprint Addresses == "" then CA = FA.
# - Remove "(corresponding author)" from CA names.
# - Region only for China/USA; Taiwan -> "Taiwan"; others -> NA.
# - Address blocks may contain MULTIPLE authors in one bracket: [A; B; C] ...
#
# Institute / Department extraction rules (per latest instruction):
# - Institute: take the FIRST organization segment after the bracket (typically the school/university),
#            NOT the 2nd segment (college).
# - Department (FADept/CAdept):
#     1) Prefer an org segment that contains Dept/Department (case-insensitive). If multiple, take the LAST one.
#     2) If none, fall back by keyword priority (take LAST match):
#           Inst  -> Div -> Dis -> Ctr -> Coll -> Sch
#     3) If still none, positional fallback:
#           org_parts has 3+ segments => take 3rd
#           org_parts has 2 segments  => take 2nd
# - Dept cleaning: remove leading labels (Dept/Department/Inst/Div/Dis/Ctr/Sch) but keep the core name.
#
# CRITICAL FIX:
# - Do NOT split Addresses by ';' directly because semicolons are used inside brackets to separate authors.
#   We extract blocks by matching patterns like "[...]" and taking the following affiliation text
#   until the next "[". This prevents artifacts like "[Cheng" leaking into institute/dept/country.
# ------------------------------------------------------------

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(readxl)
  library(stringr)
})

.trim_na <- function(x){
  x <- ifelse(is.na(x), "", as.character(x))
  trimws(x)
}

# ---- scalar guards (prevent 'condition length > 1') ----
.scalar1 <- function(x){
  if (length(x) == 0) return(NA_character_)
  x[1]
}
.blank1 <- function(x){
  x <- .trim_na(.scalar1(x))
  !nzchar(x)
}

# generic semicolon splitter (NOT for Addresses blocks)
.split_semis <- function(x){
  x <- .trim_na(x)
  if (!nzchar(x)) return(character(0))
  x <- gsub("\\s*;+\\s*", ";", x)
  x <- gsub("^;+|;+$", "", x)
  toks <- unlist(strsplit(x, ";", fixed = TRUE), use.names = FALSE)
  toks <- trimws(toks)
  toks[toks != ""]
}

# Addresses block extractor: keep bracketed author list + its affiliation together.
# Example: "[A; B] Univ, Dept X, City, Country; [C] Hosp, Dept Y, City, Country"
.split_address_blocks <- function(x){
  x <- .trim_na(.scalar1(x))
  if (.blank1(x)) return(character(0))
  # each block begins with "[" and ends right before the next "[" (or string end)
  blocks <- unlist(str_extract_all(x, "\\[[^\\]]+\\][^\\[]*"), use.names = FALSE)
  blocks <- trimws(blocks)
  blocks <- gsub("^;+\\s*", "", blocks)
  blocks <- gsub(";+$", "", blocks)
  blocks <- trimws(blocks)
  blocks[blocks != ""]
}

.pick_col <- function(df, candidates){
  nms <- names(df)
  hit <- candidates[candidates %in% nms]
  if (length(hit)) hit[1] else NA_character_
}

.get_col <- function(df, candidates){
  nm <- .pick_col(df, candidates)
  if (is.na(nm)) return(rep(NA_character_, nrow(df)))
  x <- df[[nm]]
  if (is.factor(x)) x <- as.character(x)
  if (inherits(x, "Date")) x <- as.character(x)
  x <- as.character(x)
  if (length(x) == 0) return(rep(NA_character_, nrow(df)))
  if (length(x) != nrow(df)) x <- rep_len(x, nrow(df))
  x
}

.normalize_country <- function(x){
  x <- .scalar1(x)
  x <- .trim_na(x)
  if (.blank1(x)) return(NA_character_)
  x <- str_replace_all(x, "\\.$", "")
  x <- str_replace_all(x, "^(U\\.?S\\.?A?|U\\.?S\\.?|United States)$", "USA")
  x <- str_replace_all(x, "^(U\\.?K\\.?|United Kingdom)$", "United Kingdom")
  x
}

.clean_dept <- function(x){
  x <- .trim_na(x)
  if (!nzchar(x)) return(NA_character_)

  # VBA-like stripping of leading labels (your list)
  x <- gsub("^\\s*(Dept\\.?|Department)\\s+", "", x, ignore.case = TRUE)
  x <- gsub("^\\s*(Inst\\.?|Institute)\\s+", "", x, ignore.case = TRUE)
  x <- gsub("^\\s*(Div\\.?|Division)\\s+", "", x, ignore.case = TRUE)
  x <- gsub("^\\s*(Dis\\.?|Discipline)\\s+", "", x, ignore.case = TRUE)
  x <- gsub("^\\s*(Ctr\\.?|Center)\\s+", "", x, ignore.case = TRUE)
  # per your note, do NOT strip Coll by default
  x <- gsub("^\\s*(Sch\\.?|School)\\s+", "", x, ignore.case = TRUE)

  x <- trimws(x)
  ifelse(nzchar(x), x, NA_character_)
}

.strip_corresponding <- function(x){
  x <- .scalar1(x)
  x <- .trim_na(x)
  if (.blank1(x)) return(NA_character_)
  x <- gsub("\\s*\\(corresponding author\\)\\s*", "", x, ignore.case = TRUE)
  x <- trimws(x)
  ifelse(nzchar(x), x, NA_character_)
}

.gate_region <- function(country, region){
  country <- .normalize_country(.scalar1(country))
  region  <- .trim_na(.scalar1(region))
  if (is.na(country) || .blank1(country)) return(NA_character_)

  # Project rule:
  # - Region only for China/USA.
  # - Taiwan is treated as its own region label (always "Taiwan").
  #   (Do NOT use city like Tainan/Hsinchu as Region.)
  if (country == "Taiwan") return("Taiwan")
  if (.blank1(region)) return(NA_character_)
  if (country %in% c("USA","China")) region else NA_character_
}

# Parse a single address block: "[A; B] Inst, Dept X, City, Country"
.parse_block <- function(block){
  block <- .trim_na(.scalar1(block))
  if (.blank1(block)) return(list(authors=character(0), aff=""))
  m <- str_match(block, "^\\s*\\[([^\\]]+)\\]\\s*(.*)$")
  if (is.na(m[1,1])) {
    return(list(authors=character(0), aff=block))
  }
  authors <- .split_semis(m[1,2])
  list(authors=authors, aff=.trim_na(m[1,3]))
}

# Pick affiliation for a target author (token can be full name or short like "Lai, FJ")
.pick_aff_for_author <- function(addresses_raw, author_token){
  blocks <- .split_address_blocks(addresses_raw)
  if (!length(blocks)) return(NA_character_)
  tok <- tolower(.trim_na(.scalar1(author_token)))
  if (.blank1(tok)) return(NA_character_)
  for (b in blocks){
    pb <- .parse_block(b)
    if (length(pb$authors)){
      # match if any author in bracket contains token (case-insensitive)
      hit <- any(str_detect(tolower(pb$authors), fixed(tok)))
      if (hit) return(pb$aff)
    }
  }
  # fallback: first block's affiliation part
  .parse_block(blocks[1])$aff
}

# Choose dept segment by priority rules; returns NA_character_ if none
.choose_dept_segment <- function(org_parts){
  org_parts <- org_parts[nzchar(org_parts)]
  if (!length(org_parts)) return(NA_character_)

  # 1) Dept/Department preferred; take LAST match
  idx <- which(str_detect(org_parts, regex("\\bDept\\b|\\bDepartment\\b", ignore_case = TRUE)))
  if (length(idx)) return(org_parts[max(idx)])

  # 2) Keyword fallback priority; take LAST match in the first category that matches
  pri <- list(
    Inst = "\\bInst\\b|\\bInstitute\\b",
    Div  = "\\bDiv\\b|\\bDivision\\b",
    Dis  = "\\bDis\\b|\\bDiscipline\\b",
    Ctr  = "\\bCtr\\b|\\bCenter\\b",
    Coll = "\\bColl\\b|\\bCollege\\b",
    Sch  = "\\bSch\\b|\\bSchool\\b"
  )
  for (k in names(pri)){
    idx <- which(str_detect(org_parts, regex(pri[[k]], ignore_case = TRUE)))
    if (length(idx)) return(org_parts[max(idx)])
  }

  # 3) Positional fallback
  if (length(org_parts) >= 3) return(org_parts[3])
  if (length(org_parts) == 2) return(org_parts[2])
  NA_character_
}

# Extract institute/department/country/region from affiliation part (no bracket)
.extract_meta_from_aff <- function(aff){
  aff <- .trim_na(.scalar1(aff))
  if (.blank1(aff)) {
    return(list(institute=NA_character_, dept=NA_character_, region=NA_character_, country=NA_character_))
  }

  parts <- str_split(aff, ",\\s*")[[1]]
  parts <- parts[nzchar(parts)]
  if (!length(parts)) {
    return(list(institute=NA_character_, dept=NA_character_, region=NA_character_, country=NA_character_))
  }

  country <- .normalize_country(tail(parts, 1))
  region  <- if (length(parts) >= 2) parts[length(parts)-1] else NA_character_

  # ---- organization chain (drop trailing region/country when present) ----
  org_parts <- parts
  if (length(org_parts) >= 3) org_parts <- org_parts[1:(length(org_parts)-2)]
  org_parts <- org_parts[nzchar(org_parts)]

  # institute: ALWAYS take first org segment (school/university)
  inst <- if (length(org_parts) >= 1) org_parts[1] else parts[1]

  # dept: per rule (prefer Dept; else Inst/Div/Dis/Ctr/Coll/Sch; else positional)
  dept_raw <- .choose_dept_segment(org_parts)

  list(
    institute = .trim_na(inst),
    dept      = .clean_dept(dept_raw),
    region    = .trim_na(region),
    country   = country
  )
}

# Map short authors -> full names by position between "Authors" and "Author Full Names"
.map_short_to_full <- function(authors_short, authors_full){
  s <- .split_semis(authors_short)
  f <- .split_semis(authors_full)
  if (!length(s) || !length(f)) return(list())
  n <- min(length(s), length(f))
  s <- s[seq_len(n)]; f <- f[seq_len(n)]
  as.list(setNames(f, s))
}

.first_full_author <- function(authors_full, authors_short=NULL){
  f <- .split_semis(authors_full)
  if (length(f)) return(f[1])
  s <- .split_semis(authors_short)
  if (length(s)) return(s[1])
  NA_character_
}

.ca_from_reprint <- function(reprint_raw, authors_short, authors_full){
  rp <- .trim_na(.scalar1(reprint_raw))
  # if blank, CA is FA
  if (.blank1(rp)) return(.first_full_author(authors_full, authors_short))
  # get token at start: "Last, FI ..." (strip "(corresponding author)" later)
  m <- str_match(rp, "^\\s*([^,;]+,\\s*[^,;()]+)")
  ca_short <- ifelse(is.na(m[1,2]), "", .trim_na(m[1,2]))
  ca_short <- .strip_corresponding(ca_short)
  if (!nzchar(ca_short)) return(.first_full_author(authors_full, authors_short))

  mp <- .map_short_to_full(authors_short, authors_full)
  if (length(mp) && !is.null(mp[[ca_short]])) return(mp[[ca_short]])

  # fallback: keep short (already stripped)
  ca_short
}

# ---------------------------
# Routine 1
# ---------------------------
make_woswide32 <- function(xls_path, base_letter = NULL){
  raw <- if (is.data.frame(xls_path) || inherits(xls_path, "tbl_df")) xls_path else readxl::read_excel(xls_path)

  citation <- .get_col(raw, c("Times Cited, WoS Core", "Times Cited", "Times Cited, All Databases", "Citation"))
  pubyear  <- .get_col(raw, c("Publication Year", "Year Published", "Year"))
  journal  <- .get_col(raw, c("Journal ISO Abbreviation", "Journal Abbreviation", "Source Title", "Journal"))

  authors  <- .get_col(raw, c("Authors", "AU"))
  aufull   <- .get_col(raw, c("Author Full Names", "Full Author Names"))
  title    <- .get_col(raw, c("Article Title", "Document Title", "Title", "TI"))

  addresses <- .get_col(raw, c("Addresses", "C1"))
  reprint   <- .get_col(raw, c("Reprint Addresses", "RP"))
  email     <- .get_col(raw, c("E-mail Addresses", "Email Addresses", "EM"))

  auth_kw   <- .get_col(raw, c("Author Keywords", "DE"))
  kw_plus   <- .get_col(raw, c("Keywords Plus", "ID"))

  doc_type  <- .get_col(raw, c("Document Type", "DT"))
  source_title <- .get_col(raw, c("Source Title", "SO"))

  # VBA: CR (Research Areas) -> Discipince1; WC (WoS Categories) -> Discipince2
  disc1 <- .get_col(raw, c("Research Areas", "Research Area"))
  disc2 <- .get_col(raw, c("WoS Categories", "Web of Science Categories", "Web of Science Categories / WoS Categories"))

  wos_index <- .get_col(raw, c("Web of Science Index", "WoS Index"))

  pg <- .get_col(raw, c("Pages", "Page", "PG"))
  er <- .get_col(raw, c("ER"))
  ff <- .get_col(raw, c("ff"))

  wc <- ifelse(is.na(disc2) | disc2 == "", NA_character_, str_split_fixed(disc2, ";[[:space:]]*", 2)[,1])

  tibble(
    Citation = citation,
    `Publication Year` = pubyear,
    Journal = journal,
    FAauthor = NA_character_,
    Authors = authors,
    `Author Full Names` = aufull,
    TI = title,
    CAauthor = NA_character_,
    Dummy = NA_character_,
    makr = "A",
    Discipince1 = disc1,
    Addresses = addresses,
    `Reprint Addresses` = reprint,
    EM = email,
    `Author Keywords` = auth_kw,
    `Keywords Plus` = kw_plus,
    `Document Type` = doc_type,
    `Source Title` = source_title,
    PG = pg,
    WC = wc,
    WE = wos_index,
    Discipince2 = disc2,
    ER = er,
    ff = ff,
    FAcountry = NA_character_,
    CAcountry = NA_character_,
    FAinstitute = NA_character_,
    CAinstitute = NA_character_,
    FADept = NA_character_,
    CAdept = NA_character_,
    FAregion = NA_character_,
    CAregion = NA_character_
  )
}

# ---------------------------
# Routine 2/3: wide32 -> long32 (still 32 cols + row_id + article_id)
# ---------------------------
make_woslong32 <- function(woswide32, lookup_dir = "data"){
  df <- as.data.frame(woswide32)
  if (!"row_id" %in% names(df)) df$row_id <- seq_len(nrow(df))
  if (!"article_id" %in% names(df)) df$article_id <- df$row_id

  # compute FA/CA names (prefer FULL)
  FA_full <- vapply(seq_len(nrow(df)), function(i){
    .first_full_author(df$`Author Full Names`[i], df$Authors[i])
  }, FUN.VALUE = character(1))

  CA_full <- vapply(seq_len(nrow(df)), function(i){
    .ca_from_reprint(df$`Reprint Addresses`[i], df$Authors[i], df$`Author Full Names`[i])
  }, FUN.VALUE = character(1))

  # remove "(corresponding author)" if any leakage
  CA_full <- vapply(CA_full, .strip_corresponding, FUN.VALUE = character(1))

  # pick address block and extract meta
  meta_fa <- lapply(seq_len(nrow(df)), function(i){
    aff <- .pick_aff_for_author(df$Addresses[i], FA_full[i])
    .extract_meta_from_aff(aff)
  })
  meta_ca <- lapply(seq_len(nrow(df)), function(i){
    aff <- .pick_aff_for_author(df$Addresses[i], CA_full[i])
    .extract_meta_from_aff(aff)
  })

  df$FAauthor <- FA_full
  df$Caauthor <- CA_full
  # compatibility aliases used by other modules
  df$FA <- FA_full
  df$CA <- CA_full
  df$CAauthor <- CA_full
  df$FAcountry   <- vapply(meta_fa, function(x) x$country, FUN.VALUE = character(1))
  df$CAcountry   <- vapply(meta_ca, function(x) x$country, FUN.VALUE = character(1))
  df$FAinstitute <- vapply(meta_fa, function(x) x$institute, FUN.VALUE = character(1))
  df$CAinstitute <- vapply(meta_ca, function(x) x$institute, FUN.VALUE = character(1))
  df$FADept      <- vapply(meta_fa, function(x) x$dept, FUN.VALUE = character(1))
  df$CAdept      <- vapply(meta_ca, function(x) x$dept, FUN.VALUE = character(1))

  # region gate: only China/USA (+ Taiwan constant)
  fa_region_raw <- vapply(meta_fa, function(x) x$region, FUN.VALUE = character(1))
  ca_region_raw <- vapply(meta_ca, function(x) x$region, FUN.VALUE = character(1))
  df$FAregion <- mapply(.gate_region, df$FAcountry, fa_region_raw, USE.NAMES = FALSE)
  df$CAregion <- mapply(.gate_region, df$CAcountry, ca_region_raw, USE.NAMES = FALSE)

  # clean trailing dots in countries
  df$FAcountry <- vapply(df$FAcountry, .normalize_country, FUN.VALUE = character(1))
  df$CAcountry <- vapply(df$CAcountry, .normalize_country, FUN.VALUE = character(1))

  # ensure order
  df %>% dplyr::select(
    Citation, `Publication Year`, Journal, FAauthor, Authors, `Author Full Names`, TI, Caauthor,
    Dummy, makr, Discipince1, Addresses, `Reprint Addresses`, EM, `Author Keywords`, `Keywords Plus`,
    `Document Type`, `Source Title`, PG, WC, WE, Discipince2, ER, ff,
    FAcountry, CAcountry, FAinstitute, CAinstitute, FADept, CAdept, FAregion, CAregion,
    row_id, article_id
  )
}
