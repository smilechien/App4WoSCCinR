
# R/wos_pipeline.R
# ------------------------------------------------------------
# WoS author export -> wide32 -> long32 -> long16 -> metatable -> summary report
# Designed to be robust to header variations and avoid illegal escapes.
# ------------------------------------------------------------

suppressPackageStartupMessages({
  library(dplyr)
  library(stringr)
  library(tidyr)
  library(readxl)
})

# ---------- helpers ----------
trim_na <- function(x){
  x <- as.character(x)
  x[is.na(x)] <- ""
  str_trim(x)
}

excel_col_to_num <- function(col){
  col <- toupper(trim_na(col))
  if (!nzchar(col)) stop("Empty excel column letter")
  letters <- strsplit(col, "")[[1]]
  n <- 0L
  for (ch in letters){
    n <- n * 26L + (match(ch, LETTERS))
  }
  n
}

.get_col <- function(df, candidates){
  nm <- names(df)
  for (c in candidates){
    hit <- which(tolower(nm) == tolower(c))
    if (length(hit) == 1) return(df[[hit]])
  }
  # partial match
  for (c in candidates){
    hit <- which(str_detect(tolower(nm), fixed(tolower(c))))
    if (length(hit) >= 1) return(df[[hit[1]]])
  }
  return(rep(NA_character_, nrow(df)))
}

split_semis <- function(x){
  x <- trim_na(x)
  if (!nzchar(x)) return(character())
  parts <- unlist(str_split(x, ";"))
  parts <- trim_na(parts)
  parts[parts != ""]
}

first_nonempty <- function(x){
  x <- trim_na(x)
  x[x != ""][1] %||% ""
}
`%||%` <- function(a,b){ if (!is.null(a) && length(a) > 0 && !is.na(a)) a else b }

# h-index from citation vector (numeric)
h_index <- function(cites){
  cites <- suppressWarnings(as.numeric(cites))
  cites <- cites[!is.na(cites)]
  if (length(cites) == 0) return(0L)
  cites <- sort(cites, decreasing = TRUE)
  h <- 0L
  for (i in seq_along(cites)){
    if (cites[i] >= i) h <- i else break
  }
  as.integer(h)
}

# ---------- Routine 1 ----------
# Build standardized 32-column table. Two modes:
# 1) header-based (preferred)
# 2) Excel-letter-based slice (fallback) using base_letter (default "AG")
make_woswide32 <- function(xls_path, base_letter = "AG"){
  raw <- readxl::read_excel(xls_path)

  # If it already looks like a WoS "full record" export, header-based works best.
  citation <- .get_col(raw, c("Times Cited, WoS Core", "Times Cited", "Times Cited, All Databases", "Citations", "Citation"))
  pubyear  <- .get_col(raw, c("Publication Year", "Year", "PY"))
  journal  <- .get_col(raw, c("Journal ISO Abbreviation", "Journal Abbreviation", "Source Title", "SO", "Journal"))
  pt       <- .get_col(raw, c("PT", "Publication Type"))
  authors  <- .get_col(raw, c("Authors", "AU"))
  aufull   <- .get_col(raw, c("Author Full Names", "Full Author Names", "AF"))
  ti       <- .get_col(raw, c("Article Title", "Document Title", "Title", "TI"))
  la       <- .get_col(raw, c("LA", "Language"))
  addresses <- .get_col(raw, c("Addresses", "C1"))
  reprint   <- .get_col(raw, c("Reprint Addresses", "RP"))
  em        <- .get_col(raw, c("E-mail Addresses", "Email Addresses", "EM"))
  de        <- .get_col(raw, c("Author Keywords", "DE"))
  id        <- .get_col(raw, c("Keywords Plus", "ID"))
  dt        <- .get_col(raw, c("Document Type", "DT"))
  so        <- .get_col(raw, c("Source Title", "SO"))
  pg        <- .get_col(raw, c("Pages", "PG"))
  wc        <- .get_col(raw, c("WoS Categories", "Web of Science Categories", "WC"))
  we        <- .get_col(raw, c("Web of Science Index", "WoS Index", "WE"))
  ra        <- .get_col(raw, c("Research Areas", "Research Area", "SU"))
  er        <- .get_col(raw, c("End Page", "ER"))
  ff        <- .get_col(raw, c("Funding Agency and Grant Number", "FU", "Funding Text", "FT"))

  df <- tibble(
    Citation = trim_na(citation),
    `Publication Year` = trim_na(pubyear),
    Journal = trim_na(journal),
    PT = trim_na(pt),
    Authors = trim_na(authors),
    `Author Full Names` = trim_na(aufull),
    TI = trim_na(ti),
    LA = trim_na(la),
    country = NA_character_,      # placeholder (original VBA had two "country" columns)
    country2 = NA_character_,
    Discipince1 = trim_na(ra),
    Addresses = trim_na(addresses),
    `Reprint Addresses` = trim_na(reprint),
    EM = trim_na(em),
    `Author Keywords` = trim_na(de),
    `Keywords Plus` = trim_na(id),
    `Document Type` = trim_na(dt),
    `Source Title` = trim_na(so),
    PG = trim_na(pg),
    WC = trim_na(wc),
    WE = trim_na(we),
    Discipince2 = trim_na(wc),
    ER = trim_na(er),
    ff = trim_na(ff),
    FAcountry = NA_character_,
    CAcountry = NA_character_,
    FAinstitute = NA_character_,
    CAinstitute = NA_character_,
    FADept = NA_character_,
    CAdept = NA_character_,
    FAregion = NA_character_,
    CAregion = NA_character_
  )

  # If most columns are empty (e.g., weird author export), try slice-by-letter fallback
  non_empty_rate <- mean(rowSums(df != "" & !is.na(df)) > 3)
  if (is.na(non_empty_rate) || non_empty_rate < 0.2){
    base_i <- excel_col_to_num(base_letter)
    if (ncol(raw) >= base_i + 31){
      sliced <- raw[, base_i:(base_i+31)]
      names(sliced) <- names(df)
      df <- as_tibble(sliced) %>% mutate(across(everything(), trim_na))
    }
  }

  df <- df %>% mutate(article_id = seq_len(n()))
  df %>% select(article_id, everything())
}

# ---------- Routine 2/3: build long32 with FA/CA domains ----------
# Extract first author from AU/Authors
first_author <- function(authors_raw){
  authors_raw <- trim_na(authors_raw)
  out <- vapply(authors_raw, function(x){
    parts <- split_semis(x)
    if (length(parts) == 0) "" else parts[1]
  }, FUN.VALUE = character(1))
  out
}

# Find a bracket block like "[Chang, CJ]" in Addresses
extract_bracket_authors <- function(block){
  block <- trim_na(block)
  m <- str_match(block, "^\\s*\\[([^\\]]+)\\]\\s*(.*)$")
  if (is.na(m[1,1])) return(list(authors="", aff=block))
  list(authors=trim_na(m[1,2]), aff=trim_na(m[1,3]))
}

# pick affiliation block that contains target author token (case-insensitive)
pick_affiliation_for_author <- function(addresses_raw, author_token){
  blocks <- split_semis(addresses_raw)
  if (length(blocks) == 0) return("")
  author_token <- tolower(trim_na(author_token))
  for (b in blocks){
    ea <- extract_bracket_authors(b)
    if (nzchar(ea$authors) && nzchar(author_token) &&
        str_detect(tolower(ea$authors), fixed(author_token))) {
      return(ea$aff)
    }
  }
  # fallback: first block's affiliation part
  extract_bracket_authors(blocks[1])$aff
}

# Corresponding author token from Reprint Addresses (best-effort)
corresponding_author <- function(reprint_raw, authors_raw){
  reprint_raw <- trim_na(reprint_raw)
  if (!nzchar(reprint_raw)) return(first_author(authors_raw))
  # common pattern: "Chang, CJ (reprint author), ..."
  m <- str_match(reprint_raw, "^\\s*([^,;]+,\\s*[^,;]+)")
  ca <- ifelse(is.na(m[,2]), "", trim_na(m[,2]))
  ca[ca==""] <- first_author(authors_raw)[ca==""]
  ca
}

# Basic country extraction: last comma token, normalize US/UK
normalize_country <- function(x){
  x <- trim_na(x)
  if (!nzchar(x)) return("")
  y <- str_split(x, ",")[[1]]
  y <- trim_na(y)
  ctry <- y[length(y)]
  ctry <- str_replace_all(ctry, "\\.$", "")
  # normalize US variants
  ctry <- str_replace_all(ctry, "^(U\\.?S\\.?A?|United States)$", "USA")
  ctry <- str_replace_all(ctry, "^(U\\.?K\\.?|United Kingdom)$", "United Kingdom")
  ctry
}

# Department extraction
extract_dept <- function(aff){
  aff <- trim_na(aff)
  if (!nzchar(aff)) return("")
  m <- str_match(aff, "(?i)(Dept\\.?\\s*[^,;]+)")
  if (!is.na(m[1,2])) return(trim_na(m[1,2]))
  m <- str_match(aff, "(?i)(Department\\s+[^,;]+)")
  if (!is.na(m[1,2])) return(trim_na(m[1,2]))
  ""
}

# Institute extraction: take first segment before Dept/Department if present
extract_inst <- function(aff){
  aff <- trim_na(aff)
  if (!nzchar(aff)) return("")
  # remove leading bracket artifacts just in case
  aff <- str_replace(aff, "^.*\\]\\s*", "")
  # cut at Dept/Department
  aff2 <- str_split(aff, regex("(?i)\\bDept\\b|\\bDepartment\\b"))[[1]][1]
  segs <- str_split(aff2, ",")[[1]]
  segs <- trim_na(segs)
  if (length(segs) == 0) return("")
  # often: "Natl Taiwan Univ Hosp" etc.
  segs[1]
}

# Region extraction using lookups
load_us_lookup <- function(path){
  if (!file.exists(path)) return(tibble(abbr=character(), full=character()))
  us <- readxl::read_excel(path)
  # expected: col1=abbr, col3=full (or col2)
  abbr <- trim_na(us[[1]])
  full <- if (ncol(us) >= 3) trim_na(us[[3]]) else trim_na(us[[2]])
  tibble(abbr=abbr, full=full)
}

load_china_cities <- function(path){
  if (!file.exists(path)) return(character())
  x <- readxl::read_excel(path, col_names = FALSE)[[1]]
  trim_na(x)
}

extract_region <- function(aff, country, china_cities=NULL, us_lookup=NULL){
  aff <- trim_na(aff); country <- normalize_country(country)
  if (!nzchar(aff) || !nzchar(country)) return("")
  if (country == "USA" && !is.null(us_lookup)){
    # match state abbreviation or full name
    for (i in seq_len(nrow(us_lookup))){
      ab <- us_lookup$abbr[i]; fu <- us_lookup$full[i]
      if (nzchar(ab) && str_detect(aff, paste0("\\b", ab, "\\b"))) return(ab)
      if (nzchar(fu) && str_detect(tolower(aff), fixed(tolower(fu)))) return(ab)
    }
    return("US")
  }
  if (country %in% c("China","People's R China","Peoples R China") && !is.null(china_cities)){
    # best-effort: look for province-like tokens in address
    # if city list contains "Taipei" etc, we won't force; just return "CN"
    hit <- china_cities[china_cities != "" & str_detect(aff, fixed(china_cities))]
    if (length(hit) >= 1) return(hit[1])
    return("CN")
  }
  if (country == "Taiwan") return("Taiwan")
  ""
}

make_woslong32 <- function(woswide32, lookup_dir = "data"){
  china_cities <- load_china_cities(file.path(lookup_dir, "chinacity.xlsx"))
  us_lookup <- load_us_lookup(file.path(lookup_dir, "US.xlsx"))

  df <- woswide32 %>%
    mutate(
      FA = first_author(Authors),
      CA = corresponding_author(`Reprint Addresses`, Authors),
      FA_aff = vapply(seq_len(n()), function(i) pick_affiliation_for_author(Addresses[i], FA[i]), FUN.VALUE = character(1)),
      CA_aff = vapply(seq_len(n()), function(i) pick_affiliation_for_author(Addresses[i], CA[i]), FUN.VALUE = character(1)),
      FA_country = vapply(FA_aff, normalize_country, FUN.VALUE = character(1)),
      CA_country = vapply(CA_aff, normalize_country, FUN.VALUE = character(1)),
      FA_dept = vapply(FA_aff, extract_dept, FUN.VALUE = character(1)),
      CA_dept = vapply(CA_aff, extract_dept, FUN.VALUE = character(1)),
      FA_institute = vapply(FA_aff, extract_inst, FUN.VALUE = character(1)),
      CA_institute = vapply(CA_aff, extract_inst, FUN.VALUE = character(1)),
      FA_region = mapply(extract_region, FA_aff, FA_country, MoreArgs=list(china_cities=china_cities, us_lookup=us_lookup)),
      CA_region = mapply(extract_region, CA_aff, CA_country, MoreArgs=list(china_cities=china_cities, us_lookup=us_lookup))
    )

  df %>%
    mutate(
      FAcountry = FA_country,
      CAcountry = CA_country,
      FAinstitute = FA_institute,
      CAinstitute = CA_institute,
      FADept = FA_dept,
      CAdept = CA_dept,
      FAregion = FA_region,
      CAregion = CA_region
    ) %>%
    select(-FA_aff, -CA_aff, -FA_country, -CA_country, -FA_dept, -CA_dept, -FA_institute, -CA_institute, -FA_region, -CA_region)
}

# ---------- long16 / metatable ----------
make_woslong16 <- function(woslong32){
  woslong32 %>%
    transmute(
      article_id,
      citation_raw = Citation,
      publication_year = `Publication Year`,
      journal = Journal,
      PT, LA,
      FA, CA,
      FAcountry, CAcountry,
      FAinstitute, CAinstitute,
      FADept, CAdept,
      FAregion, CAregion,
      Discipince1, Discipince2,
      Document.Type = `Document Type`,
      Keywords.Plus = `Keywords Plus`
    )
}

# metatable: convert Keywords Plus into binary columns keyword_plus__*
make_metatable <- function(woslong16){
  kw <- woslong16$Keywords.Plus
  kw_list <- lapply(kw, split_semis)
  vocab <- sort(unique(unlist(kw_list)))
  vocab <- vocab[vocab != ""]
  # keep reasonable size
  if (length(vocab) > 2000) vocab <- vocab[1:2000]

  bin <- vapply(vocab, function(term){
    vapply(kw_list, function(x) as.integer(term %in% x), FUN.VALUE = integer(1))
  }, FUN.VALUE = integer(length(kw_list)))

  bin <- as.data.frame(bin, check.names = FALSE)
  names(bin) <- paste0("keyword_plus__", make.names(vocab, unique = TRUE))
  bind_cols(woslong16 %>% select(-Keywords.Plus), bin)
}

# ---------- summary report (10 domains, top5 by n, with h-index) ----------
# ---------- Summary report (10 domains, top5 by n, with h-index + AAC) ----------
aac_from_top2 <- function(n1, n2){
  n1 <- suppressWarnings(as.numeric(n1)); n2 <- suppressWarnings(as.numeric(n2))
  if (is.na(n1) || n1 <= 0) return(NA_real_)
  if (is.na(n2) || n2 < 0) n2 <- 0
  den <- (n1 + n2)
  if (den == 0) return(NA_real_)
  (n1 - n2) / den
}

make_summary_report <- function(woslong16){
  df <- woslong16
  cites <- suppressWarnings(as.numeric(df$citation_raw))
  if (all(is.na(cites))) cites <- rep(0, nrow(df))
  df$citation_num <- ifelse(is.na(cites), 0, cites)

  domain_map <- list(
    Author_FA = df$FA,
    Author_CA = df$CA,
    Country_FA = df$FAcountry,
    Country_CA = df$CAcountry,
    Institute_FA = df$FAinstitute,
    Institute_CA = df$CAinstitute,
    Department_FA = df$FADept,
    Department_CA = df$CAdept,
    Region_FA = df$FAregion,
    Region_CA = df$CAregion
  )

  rows <- list()
  for (dn in names(domain_map)){
    vec <- trim_na(domain_map[[dn]])
    ok <- vec != ""
    if (!any(ok)) next

    tmp <- tibble(element = vec[ok], citation = df$citation_num[ok])
    summ_all <- tmp %>%
      group_by(element) %>%
      summarise(
        n = n(),
        h_index = h_index(citation),
        .groups = "drop"
      ) %>%
      arrange(desc(n), desc(h_index), element)

    # AAC computed from top1/top2 n in this domain
    n1 <- if (nrow(summ_all) >= 1) summ_all$n[[1]] else NA_real_
    n2 <- if (nrow(summ_all) >= 2) summ_all$n[[2]] else 0
    aac <- aac_from_top2(n1, n2)

    summ <- summ_all %>%
      slice_head(n = 5) %>%
      mutate(domain = dn, AAC = aac) %>%
      select(domain, AAC, element, n, h_index)

    rows[[dn]] <- summ
  }
  bind_rows(rows)
}

# ---------- Summary PNG (paired domains in 2 columns) ----------
make_summary_png <- function(summary_df, outfile, width = 1400, height = 2200, res = 160){
  # Expected domains (paired): FA vs CA for 5 groups
  pairs <- list(
    c("Author_FA","Author_CA"),
    c("Country_FA","Country_CA"),
    c("Institute_FA","Institute_CA"),
    c("Department_FA","Department_CA"),
    c("Region_FA","Region_CA")
  )

  # Create a lookup
  sd <- summary_df
  if (!all(c("domain","AAC","element","n","h_index") %in% names(sd))){
    stop("summary_df must have columns: domain, AAC, element, n, h_index")
  }

  # normalize domain ordering
  sd$domain <- as.character(sd$domain)
  sd$element <- as.character(sd$element)

  png(outfile, width = width, height = height, res = res)
  oldpar <- par(no.readonly = TRUE)
  on.exit({par(oldpar); dev.off()}, add = TRUE)

  par(mfrow = c(length(pairs), 2), mar = c(1.5, 1.5, 3.0, 1.0), oma = c(2,2,3,2))

  for (r in seq_along(pairs)){
    for (cidx in 1:2){
      dn <- pairs[[r]][[cidx]]
      sub <- sd[sd$domain == dn, , drop = FALSE]
      plot.new()
      title_line <- dn
      if (nrow(sub) > 0 && !all(is.na(sub$AAC))){
        aac <- unique(sub$AAC)
        aac <- aac[!is.na(aac)]
        if (length(aac) > 0){
          title_line <- paste0(dn, "  (AAC=", sprintf("%.3f", aac[[1]]), ")")
        }
      }
      title(main = title_line, cex.main = 1.0)

      # draw header
      text(0.02, 0.88, "label", adj = c(0,0.5), cex = 0.9, font = 2)
      text(0.78, 0.88, "n",     adj = c(1,0.5), cex = 0.9, font = 2)
      text(0.98, 0.88, "h",     adj = c(1,0.5), cex = 0.9, font = 2)

      if (nrow(sub) == 0){
        text(0.5, 0.5, "(empty)", cex = 1.0)
      } else {
        y <- seq(0.75, 0.15, length.out = max(5, nrow(sub)))
        sub <- sub[order(-sub$n, -sub$h_index, sub$element), , drop = FALSE]
        sub <- head(sub, 5)
        for (i in seq_len(nrow(sub))){
          text(0.02, y[i], sub$element[i], adj = c(0,0.5), cex = 0.88)
          text(0.78, y[i], as.character(sub$n[i]), adj = c(1,0.5), cex = 0.88)
          text(0.98, y[i], as.character(sub$h_index[i]), adj = c(1,0.5), cex = 0.88)
        }
      }
    }
  }

  mtext("Summary report: 10 domains (Top 5 by n) with h-index and AAC", outer = TRUE, side = 3, cex = 1.1, font = 2)
  mtext("Generated by WoS VBA Port", outer = TRUE, side = 1, cex = 0.9)
  invisible(outfile)
}
