# make_final_from_woslong.R
# Purpose: Build final metadata table from woslong (produced by wos_build_woslong)
# Rules (WoS):
# 1) Corresponding author (CA) MUST be determined by "Reprint Addresses" when available.
#    If CA cannot be parsed, fallback to FA.
# 2) FA/CA country/region/institute/department MUST be extracted from "Addresses"
#    using the author-matched "[Name] ..." block when possible.
# 3) Keywords: use Keywords Plus only -> expand to A1..A13.
suppressPackageStartupMessages({
  library(dplyr)
  library(stringr)
})

.trim_na <- function(x){
  x <- ifelse(is.na(x), "", as.character(x))
  trimws(x)
}

# robust column picker (case-insensitive; tolerates duplicated headers .1/.2)
.pick_col <- function(df, candidates){
  nms <- names(df)
  nms_l <- tolower(nms)
  cand_l <- tolower(candidates)

  # exact match
  hit <- which(nms_l %in% cand_l)
  if (length(hit)) return(nms[hit[1]])

  # match after stripping suffixes like .1 .2
  base_l <- sub("\\.[0-9]+$", "", nms_l)
  hit2 <- which(base_l %in% cand_l)
  if (length(hit2)) return(nms[hit2[1]])

  # contains
  for (c in cand_l){
    h <- which(grepl(c, nms_l, fixed = TRUE))
    if (length(h)) return(nms[h[1]])
  }
  NA_character_
}

.safe_get <- function(df, col, default=""){
  n <- nrow(df)
  if (is.na(col) || !nzchar(col) || !(col %in% names(df))) return(rep(default, n))
  v <- df[[col]]
  if (length(v) != n) v <- rep(v[1], n)
  v
}

# Keywords Plus -> A1..A13
.keywordsplus_to_Acols <- function(kp_vec, max_k = 13){
  kp_vec <- .trim_na(kp_vec)

  split_one <- function(x){
    if (!nzchar(x)) return(character(0))
    x <- gsub("\\s*;+\\s*", ";", x)
    x <- gsub("^;+|;+$", "", x)
    toks <- unlist(strsplit(x, ";", fixed = TRUE), use.names = FALSE)
    toks <- trimws(toks)
    toks[toks != ""]
  }

  toks_list <- lapply(kp_vec, split_one)
  mat <- t(vapply(toks_list, function(v){
    v <- v[seq_len(min(length(v), max_k))]
    if (length(v) < max_k) v <- c(v, rep("", max_k - length(v)))
    v
  }, FUN.VALUE = character(max_k)))

  out <- as.data.frame(mat, stringsAsFactors = FALSE)
  names(out) <- paste0("A", seq_len(max_k))
  out
}

# Parse "Lai, FJ (corresponding author), ..." -> "Lai, FJ"
.parse_ca_from_reprint <- function(reprint_raw){
  x <- .trim_na(reprint_raw)
  # take before first comma
  lead <- str_split_fixed(x, ",", 2)[,1]
  lead <- str_replace_all(lead, "\\s*\\(corresponding author\\)\\s*", "")
  lead <- str_replace_all(lead, "\\s+", " ")
  lead <- trimws(lead)

  # keep only "Surname, Initials" pattern
  ok <- str_detect(lead, "^[A-Za-z\\-\\' ]+,\\s*[A-Za-z]{1,4}$")
  out <- ifelse(ok, lead, "")
  out
}

# Convert "Lai, FJ" -> list(surname="Lai", init="F")
.short_to_key <- function(short){
  short <- .trim_na(short)
  parts <- str_split_fixed(short, ",", 2)
  surname <- trimws(parts[,1])
  inits <- trimws(parts[,2])
  init1 <- ifelse(nzchar(inits), substr(inits, 1, 1), "")
  list(surname = surname, init1 = init1)
}

# Extract the best-matching "[Name] ..." block from Addresses for a short author name
.find_author_block_one <- function(address_raw, author_short){
  # Returns the best-matching [Author] ... block from a single Addresses string.
  a <- .trim_na(author_short)
  if (!nzchar(a)) return("")
  addr <- .trim_na(address_raw)
  if (!nzchar(addr)) return("")

  # prefer exact [Full Name] block when possible
  # author_short may be like "Lai, FJ" or "Li, MJ"
  # parse surname + initials
  sur <- str_trim(str_split_fixed(a, ",", 2)[,1])
  ini <- ""
  if (str_detect(a, ",")) {
    rest <- str_trim(str_split_fixed(a, ",", 2)[,2])
    ini <- toupper(gsub("[^A-Za-z]", "", rest))
  }
  sur_u <- toupper(sur)

  blks <- unlist(str_split(addr, "\\s*;\\s*"))
  if (length(blks)==0) return("")
  # normalize blocks to ensure leading [ if missing
  blks <- vapply(blks, function(b){
    b <- .trim_na(b)
    if (!nzchar(b)) return("")
    if (substr(trimws(b),1,1)!="[") b <- paste0("[", b)
    b
  }, character(1))
  blks <- blks[nzchar(blks)]
  if (length(blks)==0) return("")

  # filter blocks that contain surname (case-insensitive)
  cand <- blks[str_detect(toupper(blks), fixed(sur_u))]
  if (length(cand)==0) return("")
  if (!nzchar(ini)) return(cand[1])

  # score by initials appearing near surname in the bracket author section
  score_block <- function(b){
    # take bracket part
    m <- regmatches(b, regexpr("\\[[^\\]]+\\]", b))
    if (!length(m)) return(0L)
    br <- toupper(m[1])
    # initials match (e.g., FJ or M J)
    if (str_detect(br, ini)) return(2L)
    # any initial letter match
    if (nchar(ini)>=1 && str_detect(br, substr(ini,1,1))) return(1L)
    0L
  }
  sc <- vapply(cand, score_block, integer(1))
  cand[which.max(sc)]
}

# Extract country/region/institute/dept from a matched address block "[Name] X, Y, Z, Country"
.extract_meta_from_block <- function(block){
  b <- .trim_na(block)
  if (!nzchar(b)) return(list(country="", region="", institute="", dept=""))

  # remove bracketed name
  b2 <- str_replace(b, "^\\[[^\\]]+\\]\\s*", "")
  b2 <- str_replace_all(b2, "\\s+", " ")
  b2 <- trimws(b2)

  parts <- trimws(unlist(strsplit(b2, ",", fixed = TRUE), use.names = FALSE))
  parts <- parts[parts != ""]
  if (length(parts) == 0) return(list(country="", region="", institute="", dept=""))

  country <- parts[length(parts)]
  region <- ifelse(length(parts) >= 2, parts[length(parts)-1], "")

  # dept: first token containing dept-like markers
  dept <- ""
  dept_mark <- c("Dept", "Department", "Div", "Division", "Dis", "Discipline", "Sch", "School", "Coll", "College", "Ctr", "Center", "Res Ctr", "Med Ctr")
  for (p in parts){
    if (any(str_detect(p, paste0("\\b", dept_mark, "\\b")))){
      dept <- p
      if (str_detect(dept, "\\bDept\\b")) break
    }
  }
  # clean dept prefixes (match your VBA intent)
  dept <- str_replace(dept, "^Dept\\s+", "")
  dept <- str_replace(dept, "^Div\\s+", "")
  dept <- str_replace(dept, "^Dis\\s+", "")
  dept <- str_replace(dept, "^Ctr\\s+", "")
  dept <- str_replace(dept, "^Sch\\s+", "")
  dept <- trimws(dept)

  # institute: prefer tokens with Univ/Hosp/Inst/Ctr/Med Ctr; otherwise first token
  inst <- ""
  inst_mark <- c("Univ", "University", "Hosp", "Hospital", "Inst", "Institute", "Ctr", "Center", "Med Ctr", "Medical Center", "Syst", "System")
  for (p in parts){
    if (any(str_detect(p, paste0("\\b", inst_mark, "\\b")))){
      inst <- p
      break
    }
  }
  if (!nzchar(inst)) inst <- parts[1]
  inst <- trimws(inst)

  list(country=country, region=region, institute=inst, dept=dept)
}

# Public API used by app.R
make_final_from_woslong_df <- function(df){
  stopifnot(is.data.frame(df))

  # expected woslong columns from wos_build_woslong (24 cols)
  col_citation <- .pick_col(df, c("citation_raw","Times Cited, WoS Core","Times Cited","TC","citation"))
  col_journal  <- .pick_col(df, c("journal","Journal ISO Abbreviation","SO","Source Title"))
  col_year     <- .pick_col(df, c("year","Publication Year","PY"))
  col_authors  <- .pick_col(df, c("authors_raw","Authors","AU"))
  col_addr     <- .pick_col(df, c("addresses_raw","Addresses","C1"))
  col_reprint  <- .pick_col(df, c("reprint_raw","Reprint Addresses","RP"))
  col_ra       <- .pick_col(df, c("research_areas","Research Areas"))
  col_wc       <- .pick_col(df, c("wos_categories","WoS Categories","WC"))
  # KeywordPlus raw may be split into keyword_plus_1/2 by wos_build_woslong
  col_kp1      <- .pick_col(df, c("keyword_plus_1","keywords_plus_1","Keywords Plus"))
  col_kp2      <- .pick_col(df, c("keyword_plus_2","keywords_plus_2"))

  citation <- suppressWarnings(as.numeric(.trim_na(.safe_get(df, col_citation, ""))))
  journal  <- .trim_na(.safe_get(df, col_journal, ""))
  year     <- suppressWarnings(as.integer(.trim_na(.safe_get(df, col_year, ""))))
  authors  <- .trim_na(.safe_get(df, col_authors, ""))
  addr     <- .trim_na(.safe_get(df, col_addr, ""))
  reprint  <- .trim_na(.safe_get(df, col_reprint, ""))
  disc1    <- .trim_na(.safe_get(df, col_ra, ""))
  disc2    <- .trim_na(.safe_get(df, col_wc, ""))

  kp_raw <- .trim_na(.safe_get(df, col_kp1, ""))
  kp2 <- .trim_na(.safe_get(df, col_kp2, ""))
  kp_raw <- ifelse(nzchar(kp_raw), kp_raw, kp2)
  # if both present and different, join
  kp_raw <- ifelse(nzchar(kp2) & nzchar(kp_raw) & kp2 != kp_raw, paste(kp_raw, kp2, sep="; "), kp_raw)

  # FA from first author
  fa <- ifelse(authors == "", "", str_trim(str_split_fixed(authors, ";", 2)[,1]))

  # CA from Reprint Addresses; fallback FA
  ca_from_rp <- .parse_ca_from_reprint(reprint)
  ca <- ifelse(nzchar(ca_from_rp), ca_from_rp, fa)

  # match author blocks in Addresses
  fa_block <- mapply(.find_author_block_one, addr, fa, USE.NAMES = FALSE)
  ca_block <- mapply(.find_author_block_one, addr, ca, USE.NAMES = FALSE)

  fa_meta <- lapply(fa_block, .extract_meta_from_block)
  ca_meta <- lapply(ca_block, .extract_meta_from_block)

  fa_country <- vapply(fa_meta, `[[`, character(1), "country")
  fa_region  <- vapply(fa_meta, `[[`, character(1), "region")
  fa_inst    <- vapply(fa_meta, `[[`, character(1), "institute")
  fa_dept    <- vapply(fa_meta, `[[`, character(1), "dept")

  ca_country <- vapply(ca_meta, `[[`, character(1), "country")
  ca_region  <- vapply(ca_meta, `[[`, character(1), "region")
  ca_inst    <- vapply(ca_meta, `[[`, character(1), "institute")
  ca_dept    <- vapply(ca_meta, `[[`, character(1), "dept")

  out <- tibble(
    citation = citation,
    journal  = journal,
    year     = year,
    Authors  = authors,
    Addresses = addr,
    Reprint_Addresses = reprint,
    discipline_1 = disc1,
    discipline_2 = disc2,
    keywords_plus_raw = kp_raw,
    FA = fa,
    CA = ca,
    FA_country = fa_country,
    FA_region  = fa_region,
    FA_institute = fa_inst,
    FA_dept = fa_dept,
    CA_country = ca_country,
    CA_region  = ca_region,
    CA_institute = ca_inst,
    CA_dept = ca_dept
  )

  kpA <- .keywordsplus_to_Acols(out$keywords_plus_raw, max_k = 13)
  out <- bind_cols(out, kpA)

  out <- out %>% arrange(desc(ifelse(is.na(citation), -Inf, citation)))
  out
}