# R/wos_to_pubmed_glue.R
# ------------------------------------------------------------
# Glue code: Use WoS metatable (meta_wide) as the ONLY data source
# and feed it into PubMed FLCA pipeline (modules in pubmed zip).
#
# Paste order (DO NOT change):
#   1) helpers: .trim_na, .norm_country, .get_keyword_list, .build_pair_edges
#   2) build_edges_from_meta()
#   3) run_domain_pipeline()
# ------------------------------------------------------------

suppressPackageStartupMessages({
  library(dplyr)
  library(stringr)
})

.trim_na <- function(x){
  x <- as.character(x)
  x[is.na(x)] <- ""
  trimws(x)
}

.norm_country <- function(x){
  x <- .trim_na(x)
  # Minimal normalization for maps (keep mapping keys stable)
  x <- stringr::str_replace_all(x, "^U\\.?S\\.?$|^US$|^USA$|^United States of America$", "United States")
  x <- stringr::str_replace_all(x, "^U\\.?K\\.?$|^UK$", "United Kingdom")
  x
}

.get_keyword_list <- function(row, keyword_cols = NULL, keyword_field = NULL){
  kws <- character(0)

  if (!is.null(keyword_cols)) {
    vals <- unlist(row[keyword_cols], use.names = FALSE)
    vals <- .trim_na(vals)
    vals <- vals[nzchar(vals)]
    kws <- c(kws, vals)
  }

  if (!is.null(keyword_field) && keyword_field %in% names(row)) {
    s <- .trim_na(row[[keyword_field]])
    if (nzchar(s)) {
      parts <- stringr::str_split(s, ";|\\|", simplify = FALSE)[[1]]
      parts <- .trim_na(parts)
      parts <- parts[nzchar(parts)]
      kws <- c(kws, parts)
    }
  }

  unique(kws)
}

.build_pair_edges <- function(df, colL, colR, normalizeL = NULL, normalizeR = NULL){
  stopifnot(colL %in% names(df), colR %in% names(df))

  L <- .trim_na(df[[colL]])
  R <- .trim_na(df[[colR]])

  if (!is.null(normalizeL)) L <- normalizeL(L)
  if (!is.null(normalizeR)) R <- normalizeR(R)

  tibble(Leader = L, Follower = R, WCD = 1L) |>
    dplyr::filter(nzchar(Leader), nzchar(Follower), Leader != Follower) |>
    dplyr::count(Leader, Follower, name = "WCD", sort = TRUE)
}

build_edges_from_meta <- function(meta, domain,
                                  keyword_cols = NULL,
                                  keyword_field = NULL){

  stopifnot(is.data.frame(meta))
  dom <- tolower(.trim_na(domain))

  dom <- dplyr::case_when(
    dom %in% c("author", "authors") ~ "author",
    dom %in% c("journal/year", "journal_year", "journalyear") ~ "journal_year",
    dom %in% c("year/articles", "year_articles", "yeararticles") ~ "year_articles",
    dom %in% c("term/year", "term_year", "termyear") ~ "term_year",
    dom %in% c("country", "countries") ~ "country",
    dom %in% c("institute", "institutes") ~ "institute",
    dom %in% c("department", "dept", "departments") ~ "department",
    dom %in% c("keyword", "keywords", "mesh") ~ "keyword",
    dom %in% c("state/province", "state_province", "stateprovince", "region") ~ "region",
    TRUE ~ dom
  )

  edges <- switch(dom,
    "author" = .build_pair_edges(meta, "FAauthor", "CAauthor"),
    "journal_year" = {
      year_col <- if ("Publication Year" %in% names(meta)) "Publication Year" else "PublicationYear"
      .build_pair_edges(meta, "Journal", year_col)
    },
    "year_articles" = {
      year_col <- if ("Publication Year" %in% names(meta)) "Publication Year" else "PublicationYear"
      id_col   <- if ("article_id" %in% names(meta)) "article_id" else if ("ArticleID" %in% names(meta)) "ArticleID" else "article_id"
      .build_pair_edges(meta, year_col, id_col)
    },
    "term_year" = {
      year_col <- if ("Publication Year" %in% names(meta)) "Publication Year" else "PublicationYear"
      df <- meta

      if (is.null(keyword_cols)) {
        cand <- paste0("A", 1:13)
        keyword_cols <- cand[cand %in% names(df)]
      }

      acc <- list()
      for (i in seq_len(nrow(df))) {
        kws <- .get_keyword_list(df[i, , drop = FALSE], keyword_cols = keyword_cols, keyword_field = keyword_field)
        yr  <- .trim_na(df[[year_col]][i])
        if (!nzchar(yr) || length(kws) == 0) next
        acc[[length(acc) + 1]] <- tibble(Leader = kws, Follower = yr, WCD = 1L)
      }

      if (length(acc) == 0) tibble(Leader=character(),Follower=character(),WCD=integer())
      else dplyr::bind_rows(acc) |>
        dplyr::filter(nzchar(Leader), nzchar(Follower)) |>
        dplyr::count(Leader, Follower, name="WCD", sort=TRUE)
    },
    "country" = .build_pair_edges(meta, "FAcountry", "CAcountry", normalizeL = .norm_country, normalizeR = .norm_country),
    "institute" = .build_pair_edges(meta, "FAinstitute", "CAinstitute"),
    "department" = {
      L <- if ("FAdept" %in% names(meta)) "FAdept" else if ("FADept" %in% names(meta)) "FADept" else "FAdept"
      R <- if ("CAdept" %in% names(meta)) "CAdept" else if ("CADept" %in% names(meta)) "CADept" else "CAdept"
      .build_pair_edges(meta, L, R)
    },
    "region" = .build_pair_edges(meta, "FAregion", "CAregion"),
    "keyword" = {
      df <- meta
      if (is.null(keyword_cols)) {
        cand <- paste0("A", 1:13)
        keyword_cols <- cand[cand %in% names(df)]
      }

      acc <- list()
      for (i in seq_len(nrow(df))) {
        kws <- .get_keyword_list(df[i, , drop=FALSE], keyword_cols = keyword_cols, keyword_field = keyword_field)
        if (length(kws) < 2) next
        cmb <- utils::combn(kws, 2)
        acc[[length(acc) + 1]] <- tibble(Leader = cmb[1,], Follower = cmb[2,], WCD = 1L)
      }

      if (length(acc) == 0) tibble(Leader=character(),Follower=character(),WCD=integer())
      else dplyr::bind_rows(acc) |>
        dplyr::filter(nzchar(Leader), nzchar(Follower), Leader != Follower) |>
        dplyr::count(Leader, Follower, name="WCD", sort=TRUE)
    },
    stop("Unknown domain: ", domain)
  )

  nodes <- tibble(
    name  = unique(c(edges$Leader, edges$Follower)),
    value = 1,
    value2 = 1
  )

  list(domain = dom, nodes = nodes, edges = edges)
}

run_domain_pipeline <- function(meta, domain,
                                runner_fun = run_flca_ms_sil_runner,
                                keyword_cols = NULL,
                                keyword_field = NULL,
                                cfg = list(),
                                verbose = FALSE){

  built <- build_edges_from_meta(meta, domain,
                                keyword_cols = keyword_cols,
                                keyword_field = keyword_field)

  if (!is.data.frame(built$edges) || nrow(built$edges) == 0) {
    return(list(
      ok = FALSE,
      domain = built$domain,
      reason = "No edges built from metatable for this domain",
      built = built,
      res = NULL
    ))
  }

  res <- runner_fun(
    nodes   = built$nodes,
    edges   = built$edges,
    cfg     = cfg,
    verbose = verbose
  )

  nodes_top <- NULL
  edges_top <- NULL
  if (is.list(res)) {
    if (!is.null(res$modes)) nodes_top <- res$modes
    if (!is.null(res$data))  edges_top <- res$data
  }

  list(
    ok = TRUE,
    domain = built$domain,
    built = built,
    res = res,
    nodes_top = nodes_top,
    edges_top = edges_top
  )
}
