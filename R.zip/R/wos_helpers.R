
safestr <- function(x){
  x <- as.character(x)
  x[is.na(x)] <- ""
  x
}

split_semis <- function(x){
  x <- safestr(x)
  strsplit(x, "\\s*;\\s*")[[1]]
}

pick_first <- function(x){
  if (length(x) == 0) return(NA_character_)
  x <- x[!is.na(x) & nzchar(trimws(x))]
  if (length(x) == 0) return(NA_character_)
  trimws(x[1])
}

# Extract corresponding author full name from Reprint Addresses
extract_ca_full <- function(reprint_raw, author_full_names){
  rp <- safestr(reprint_raw)
  if (nzchar(rp)){
    # Often: "Lai, FJ (corresponding author), Chi Mei Med Ctr, ..., Taiwan."
    m <- str_match(rp, "^\\s*([^,]+),")
    if (!is.na(m[1,2])) {
      ca_short <- trimws(m[1,2])
      # If author_full_names exists, map short to full by last name
      afn <- split_semis(author_full_names)
      # find by last name prefix before comma
      last <- trimws(strsplit(ca_short, "\\s+")[[1]][1])
      hit <- afn[str_detect(afn, paste0("^", str_replace_all(last, "([\\\\\\\\\\\\\\\\.\\\\\\\\+\\\\\\\\*\\\\\\\\?\\\\\\\\^\\\\\\\\$\\\\\\\\(\\\\\\\\)\\\\\\\\\\[\\\\\\\\\\]\\\\\\\\{\\\\\\\\}\\\\\\\\|])","\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\1")))]
      if (length(hit)) return(trimws(hit[1]))
    }
  }
  # fallback: second author full name if exists
  afn <- split_semis(author_full_names)
  if (length(afn) >= 2) return(trimws(afn[2]))
  pick_first(afn)
}

# Find address block for a given full name "[Full Name]" pattern
find_address_block <- function(addresses_raw, full_name){
  addr <- safestr(addresses_raw)
  if (!nzchar(addr) || !nzchar(safestr(full_name))) return(NA_character_)
  blocks <- strsplit(addr, "\\s*;\\s*")[[1]]
  # exact bracket match
  patt <- paste0("\\\\\\\\\\[", fixed(full_name), "\\\\\\\\\\]")
  hit <- blocks[str_detect(blocks, patt)]
  if (length(hit)) return(trimws(hit[1]))
  # fallback by last name
  last <- trimws(strsplit(full_name, ",")[[1]][1])
  hit2 <- blocks[str_detect(blocks, paste0("\\\\\\\\\\[", fixed(last)))]
  if (length(hit2)) return(trimws(hit2[1]))
  trimws(blocks[1])
}

extract_country_region <- function(addr_block){
  blk <- safestr(addr_block)
  if (!nzchar(blk)) return(list(country="", region=""))
  # remove bracket prefix like "[Name] "
  blk2 <- str_replace(blk, "^\\\\\\[[^\\\\\\]]+\\\\\\]\\s*", "")
  parts <- trimws(strsplit(blk2, "\\s*,\\s*")[[1]])
  parts <- parts[nzchar(parts)]
  if (length(parts) == 0) return(list(country="", region=""))

  country <- parts[length(parts)]
  # normalize common variants
  country <- str_replace(country, "\\\\.$", "")
  country <- str_trim(country)

  # region/state/province guess: second last if exists
  region_raw <- if (length(parts) >= 2) parts[length(parts)-1] else ""
  region_raw <- str_replace(region_raw, "^CN-", "")
  # strip postal codes (e.g., "CA 94305", "Tainan 710")
  region_raw <- str_replace(region_raw, "\\s+\\d{3,6}.*$", "")
  region_raw <- str_trim(region_raw)

  # Only keep subnational region for China/USA; otherwise keep country (e.g., Taiwan)
  country_key <- toupper(country)
  if (country_key %in% c("CHINA","PRC","PEOPLE'S R CHINA","PEOPLES R CHINA","USA","UNITED STATES","UNITED STATES OF AMERICA","U.S.A.","U.S.")) {
    region <- region_raw
  } else {
    region <- country
  }

  # If parsing went wrong and left bracket/symbols, blank it
  if (str_detect(region, "^\\\\\\[")) region <- ""
  if (str_detect(country, "^\\\\\\[")) country <- ""

  list(country=country, region=region)
}

extract_institute_dept <- function(addr_block){
  blk <- safestr(addr_block)
  if (!nzchar(blk)) return(list(inst="", dept=""))
  blk2 <- str_replace(blk, "^\\\\\\[[^\\\\\\]]+\\\\\\]\\s*", "")
  parts <- trimws(strsplit(blk2, "\\s*,\\s*")[[1]])
  parts <- parts[nzchar(parts)]
  inst <- if (length(parts) >= 1) parts[1] else ""
  inst <- str_trim(inst)
  # blank if it still contains bracket artifacts
  if (str_detect(inst, "^\\\\\\[")) inst <- ""

  dept_hit <- parts[str_detect(parts, "^Dept\\\\b")]
  dept <- if (length(dept_hit)) str_trim(str_replace(dept_hit[1], "^Dept\\s*", "")) else ""
  dept <- str_trim(dept)
  list(inst=inst, dept=dept)
}

extract_ca_from_reprint <- function(reprint_raw){
  rp <- safestr(reprint_raw)
  if (!nzchar(rp)) return(list(inst="", dept="", country="", region=""))
  parts <- trimws(strsplit(rp, "\\s*,\\s*")[[1]])
  parts <- parts[nzchar(parts)]

  # country last token (strip trailing period)
  country <- if (length(parts) >= 1) str_replace(parts[length(parts)], "\\\\.$", "") else ""
  country <- str_trim(country)

  # region: only keep subnational for China/USA; otherwise keep country (e.g., Taiwan)
  region_raw <- if (length(parts) >= 2) parts[length(parts)-1] else ""
  region_raw <- str_replace(region_raw, "^CN-", "")
  region_raw <- str_replace(region_raw, "\\s+\\d{3,6}.*$", "")
  region_raw <- str_trim(region_raw)

  country_key <- toupper(country)
  if (country_key %in% c("CHINA","PRC","PEOPLE'S R CHINA","PEOPLES R CHINA","USA","UNITED STATES","UNITED STATES OF AMERICA","U.S.A.","U.S.")) {
    region <- region_raw
  } else {
    region <- country
  }

  # Inst: after the "FJ (corresponding author)" token, take the next organization token
  inst <- ""
  if (length(parts) >= 3 && str_detect(parts[2], "corresponding author")) {
    inst <- parts[3]
  } else if (length(parts) >= 2) {
    inst <- parts[2]
  }
  inst <- str_trim(inst)
  if (str_detect(inst, "corresponding author")) inst <- ""
  if (str_detect(inst, "^\\\\\\[")) inst <- ""

  # Dept: only accept true Dept tokens; otherwise blank
  dept_hit <- parts[str_detect(parts, "^Dept\\\\b")]
  dept <- if (length(dept_hit)) str_trim(str_replace(dept_hit[1], "^Dept\\s*", "")) else ""
  dept <- str_trim(dept)

  if (str_detect(country, "^\\\\\\[")) country <- ""
  if (str_detect(region, "^\\\\\\[")) region <- ""

  list(inst=inst, dept=dept, country=country, region=region)
}

# Derived32 template (exact header order, from your woslong.csv)
DERIVED32_TEMPLATE <- c(
  "Times Cited, WoS Core","Publication Year","Journal ISO Abbreviation",
  "PT","Authors","Author Full Names","TI","LA","country","country.1",
  "Research Areas","Addresses","Reprint Addresses","EM",
  "Author Keywords","Keywords Plus","Document Type","Source Title","PG","WC","WE",
  "WoS Categories","ER","ff",
  "Journal ISO Abbreviation.1","Journal ISO Abbreviation.2",
  "institute","instituteCoresp","dept","deptCoresp","Continet","Emergency"
)

force_template32 <- function(df32){
  for (nm in DERIVED32_TEMPLATE) if (!nm %in% names(df32)) df32[[nm]] <- NA_character_
  df32 <- df32[, DERIVED32_TEMPLATE, drop=FALSE]
  df32
}

build_woslong32 <- function(wos_raw){
  w <- as.data.frame(wos_raw, stringsAsFactors = FALSE)
  n <- nrow(w)

  # Raw fields
  citation <- w[["Times Cited, WoS Core"]]
  year <- w[["Publication Year"]]
  journal <- w[["Journal ISO Abbreviation"]]
  authors <- w[["Authors"]]
  author_full <- w[["Author Full Names"]]
  research_areas <- w[["Research Areas"]]
  addresses_raw <- w[["Addresses"]]
  reprint_raw <- w[["Reprint Addresses"]]
  ak <- if ("Author Keywords" %in% names(w)) w[["Author Keywords"]] else NA_character_
  kp <- if ("Keywords Plus" %in% names(w)) w[["Keywords Plus"]] else NA_character_
  doc_type <- if ("Document Type" %in% names(w)) w[["Document Type"]] else NA_character_
  source_title <- if ("Source Title" %in% names(w)) w[["Source Title"]] else NA_character_
  wos_cat <- if ("WoS Categories" %in% names(w)) w[["WoS Categories"]] else NA_character_

  # FA/CA full names
  fa_full <- vapply(author_full, function(x) pick_first(split_semis(x)), FUN.VALUE = character(1))
  ca_full <- mapply(extract_ca_full, reprint_raw, author_full, SIMPLIFY = TRUE)

  # Address blocks
  fa_addr <- mapply(find_address_block, addresses_raw, fa_full, SIMPLIFY = TRUE)
  fa_cr <- lapply(fa_addr, extract_country_region)
  fa_country <- vapply(fa_cr, `[[`, FUN.VALUE = character(1), "country")
  fa_region <- vapply(fa_cr, `[[`, FUN.VALUE = character(1), "region")
  fa_id <- lapply(fa_addr, extract_institute_dept)
  fa_inst <- vapply(fa_id, `[[`, FUN.VALUE = character(1), "inst")
  fa_dept <- vapply(fa_id, `[[`, FUN.VALUE = character(1), "dept")

  ca_info <- lapply(reprint_raw, extract_ca_from_reprint)
  ca_country <- vapply(ca_info, `[[`, FUN.VALUE = character(1), "country")
  ca_region <- vapply(ca_info, `[[`, FUN.VALUE = character(1), "region")
  ca_inst <- vapply(ca_info, `[[`, FUN.VALUE = character(1), "inst")
  ca_dept <- vapply(ca_info, `[[`, FUN.VALUE = character(1), "dept")

# ---- Clean / fallback (match your rules) ----
fa_inst <- safestr(fa_inst); fa_dept <- safestr(fa_dept)
ca_inst <- safestr(ca_inst); ca_dept <- safestr(ca_dept)

# blank values with bracket artifacts
fa_inst[str_detect(fa_inst, "^\\\\\\\\\\[")] <- ""
ca_inst[str_detect(ca_inst, "^\\\\\\\\\\[")] <- ""
fa_dept[str_detect(fa_dept, "^\\\\\\\\\\[")] <- ""
ca_dept[str_detect(ca_dept, "^\\\\\\\\\\[")] <- ""

# CA fields: drop artifacts like "FJ (corresponding author)" or multi-part strings
ca_inst[str_detect(ca_inst, "corresponding author")] <- ""
ca_dept[str_detect(ca_dept, "corresponding author|;|\\\\\\\\(")] <- ""

# If CA missing, fallback to FA (easier to verify, per your request)
ca_inst <- ifelse(!nzchar(trimws(ca_inst)) & nzchar(trimws(fa_inst)), fa_inst, ca_inst)
ca_dept <- ifelse(!nzchar(trimws(ca_dept)) & nzchar(trimws(fa_dept)), fa_dept, ca_dept)

  # Compose derived32 (match your template semantics)
  out <- data.frame(
    check.names = FALSE,
    "Times Cited, WoS Core" = citation,
    "Publication Year" = year,
    "Journal ISO Abbreviation" = journal,
    "PT" = ifelse(nzchar(fa_full), paste0(fa_full, "(", fa_country, ")"), "" ),
    "Authors" = authors,
    "Author Full Names" = author_full,
    "TI" = if ("Article Title" %in% names(w)) w[["Article Title"]] else NA_character_,
    "LA" = ifelse(nzchar(ca_full), paste0(ca_full, "(", ca_country, ")"), "" ),
    "country" = NA_character_,
    "country.1" = "A",
    "Research Areas" = research_areas,
    "Addresses" = addresses_raw,
    "Reprint Addresses" = reprint_raw,
    "EM" = NA_character_,
    "Author Keywords" = ak,
    "Keywords Plus" = kp,
    "Document Type" = doc_type,
    "Source Title" = source_title,
    "PG" = if ("Number of Pages" %in% names(w)) w[["Number of Pages"]] else NA_character_,
    "WC" = NA_character_,
    "WE" = if ("Web of Science Index" %in% names(w)) w[["Web of Science Index"]] else NA_character_,
    "WoS Categories" = wos_cat,
    "ER" = NA_character_,
    "ff" = NA_character_,
    "Journal ISO Abbreviation.1" = fa_country,
    "Journal ISO Abbreviation.2" = ca_country,
    "institute" = ifelse(nzchar(fa_inst), paste0(fa_inst, "(", fa_country, ")"), "" ),
    "instituteCoresp" = ifelse(nzchar(ca_inst), paste0(ca_inst, "(", ca_country, ")"), "" ),
    "dept" = fa_dept,
    "deptCoresp" = ca_dept,
    "Continet" = fa_region,
    "Emergency" = ca_region
  )

  out <- force_template32(out)
  out
}

build_metatable <- function(w32){
  df <- as.data.frame(w32, stringsAsFactors = FALSE)

  meta <- df %>%
    transmute(
      citation = suppressWarnings(as.integer(`Times Cited, WoS Core`)),
      year = suppressWarnings(as.integer(`Publication Year`)),
      journal = `Journal ISO Abbreviation`,
      Document_Type = `Document Type`,
      discipline_1 = `Research Areas`,
      discipline_2 = `WoS Categories`,
      FA = PT,
      CA = LA,
      FA_country = `Journal ISO Abbreviation.1`,
      CA_country = `Journal ISO Abbreviation.2`,
      FA_institute = institute,
      CA_institute = instituteCoresp,
      FA_department = dept,
      CA_department = deptCoresp,
      FA_region = Continet,
      CA_region = Emergency,
      KeywordsPlus_raw = `Keywords Plus`
    )

  # Ensure blanks instead of NA
  meta <- meta %>% mutate(across(everything(), ~safestr(.x)))

  # Expand KeywordsPlus_raw into columns keyword_plus_1..keyword_plus_13 (split by ;)
  kp_list <- strsplit(safestr(meta$KeywordsPlus_raw), "\\s*;\\s*")
  maxk <- max(vapply(kp_list, length, integer(1)))
  maxk <- min(maxk, 13)
  for (i in seq_len(maxk)){
    meta[[paste0("keyword_plus_", i)]] <- vapply(kp_list, function(v) if (length(v) >= i) trimws(v[i]) else "", FUN.VALUE = character(1))
  }

  # Drop the combined/raw field per your request
  meta$KeywordsPlus_raw <- NULL

  meta
}

# n: count rows, h: h-index on citation
h_index <- function(x){
  x <- suppressWarnings(as.numeric(x))
  x <- x[is.finite(x)]
  if (!length(x)) return(0)
  x <- sort(x, decreasing = TRUE)
  sum(x >= seq_along(x))
}

build_summary_top5 <- function(meta){
  # 8 domains
  domains <- list(
    Author_FA = "FA",
    Author_CA = "CA",
    Country_FA = "FA_country",
    Country_CA = "CA_country",
    Institute_FA = "FA_institute",
    Institute_CA = "CA_institute",
    Region_FA = "FA_region",
    Region_CA = "CA_region"
  )
  out <- list()
  for (d in names(domains)){
    col <- domains[[d]]
    tmp <- meta %>%
      filter(!is.na(.data[[col]]), nzchar(trimws(.data[[col]]))) %>%
      group_by(element = .data[[col]]) %>%
      summarise(
        n = dplyr::n(),
        h = h_index(citation),
        .groups="drop"
      ) %>%
      arrange(desc(h), desc(n), element) %>%
      slice_head(n=5) %>%
      mutate(domain = d) %>%
      select(domain, element, n, h)
    out[[d]] <- tmp
  }
  bind_rows(out)
}

plot_summary <- function(sum_df){
  # Render performance report in the same panel style as your sample script.
  # sum_df: long data with Domain, Element, n, h, Value (Value used for AAC)
  df <- as.data.frame(sum_df, stringsAsFactors = FALSE)
  if (is.null(df) || !nrow(df)) { plot.new(); title("No data"); return(invisible(NULL)) }

  domains <- c("Country","Institute","Department","Author","Journal","Year","Document","Keyword")

  op <- par(no.readonly = TRUE)
  on.exit(par(op), add=TRUE)

  par(mfrow = c(4, 2))
  par(mar = c(1.5, 1, 2.6, 1))
  par(oma = c(0, 0, 0, 0))

  for (dom in domains){
    domain_data <- df[df$Domain == dom, , drop=FALSE]

    if (!nrow(domain_data)) {
      plot.new()
      title(main = paste(dom, "(No Data)"), font.main = 2, cex.main = 1.9)
      next
    }

    # Year sorted chronologically already in build_long_perf, but keep safe:
    if (dom == "Year") {
      domain_data$yy <- suppressWarnings(as.numeric(domain_data$Element))
      domain_data <- domain_data[order(domain_data$yy), , drop=FALSE]
      domain_data$yy <- NULL
    } else {
      domain_data <- domain_data[order(-domain_data$Value), , drop=FALSE]
    }
    domain_data <- utils::head(domain_data, 5)

    values <- suppressWarnings(as.numeric(domain_data$Value))
    aac <- compute_aac(values)

    plot.new()

    title(main = dom,
          font.main = 2,
          cex.main = 1.9,
          line = 0.5,
          col.main = "red")

    # header row: Element  n  h
    text(0.05, 0.90, "Element", adj = 0, cex = 1.4, font = 2)
    text(0.82, 0.90, "n",      adj = 1, cex = 1.4, font = 2)
    text(0.95, 0.90, "h",      adj = 1, cex = 1.4, font = 2)

    n_rows <- nrow(domain_data)
    text_cex <- ifelse(n_rows <= 4, 2.2,
                       ifelse(n_rows <= 7, 1.9, 1.6))
    y_positions <- seq(0.80, 0.22, length.out = n_rows)

    for (i in seq_len(n_rows)) {
      text(0.05, y_positions[i],
           as.character(domain_data$Element[i]),
           adj = 0,
           cex = text_cex,
           font = 2)

      text(0.82, y_positions[i],
           as.character(domain_data$n[i]),
           adj = 1,
           cex = text_cex,
           font = 2)

      text(0.95, y_positions[i],
           sprintf("%.2f", as.numeric(domain_data$h[i])),
           adj = 1,
           cex = text_cex,
           font = 2)
    }

    text(0.5, 0.08,
         paste("AAC =", round(aac, 4)),
         cex = 1.6,
         font = 2)
  }

  invisible(NULL)
}


render_summary_png <- function(sum_df, path){
  png(path, width=3200, height=2400, res=300)
  plot_summary(sum_df)
  dev.off()
}




compute_aac <- function(values){
  values <- values[!is.na(values)]
  n_vals <- length(values)

  if (n_vals >= 3) {
    if (values[2] != 0 && values[3] != 0) {
      r <- (values[1] / values[2]) / (values[2] / values[3])
      return(r / (1 + r))
    } else {
      return(NA_real_)
    }
  } else if (n_vals == 2) {
    if (values[2] != 0) {
      r <- values[1] / values[2]
      return(r / (1 + r))
    } else {
      return(NA_real_)
    }
  } else if (n_vals == 1) {
    return(0.5)
  } else {
    return(NA_real_)
  }
}



build_long_perf <- function(meta){
  # Build long-format data: Domain, Element, n, h, Value(h for AAC)
  # Domains: Country, Institute, Department, Author, Journal, Year, Document, Keyword
  if (is.null(meta) || !nrow(meta)) {
    return(data.frame(Domain=character(), Element=character(), n=integer(), h=numeric(), Value=numeric(), stringsAsFactors=FALSE))
  }

  df <- as.data.frame(meta, stringsAsFactors = FALSE)

  # citation vector
  citation <- suppressWarnings(as.numeric(df[["Times Cited, WoS Core"]]))
  citation[!is.finite(citation)] <- 0

  summarise_elements <- function(elements){
    elements <- trimws(safestr(elements))
    elements <- elements[nzchar(elements)]
    if (!length(elements)) return(data.frame(Element=character(), n=integer(), h=numeric(), Value=numeric(), stringsAsFactors=FALSE))

    # For h-index per element, we need citation aligned to each element instance.
    # Here we replicate citation for stacked vectors when needed.
    # Caller should pass same-length citation vector; we do that by passing list.
    stop("summarise_elements expects list with 'element' and 'citation'")
  }

  summarise_domain <- function(Domain, element_vec, citation_vec){
    d <- data.frame(Element = trimws(safestr(element_vec)),
                    citation = suppressWarnings(as.numeric(citation_vec)),
                    stringsAsFactors=FALSE)
    d$citation[!is.finite(d$citation)] <- 0
    d <- d[nzchar(d$Element), , drop=FALSE]
    if (!nrow(d)) {
      return(data.frame(Domain=Domain, Element=character(), n=integer(), h=numeric(), Value=numeric(), stringsAsFactors=FALSE))
    }

    out <- dplyr::as_tibble(d) %>%
      dplyr::group_by(Element) %>%
      dplyr::summarise(
        n = dplyr::n(),
        h = h_index(citation),
        .groups="drop"
      ) %>%
      dplyr::arrange(dplyr::desc(h), dplyr::desc(n), Element)

    # Top 5 (Year handled later)
    out <- as.data.frame(out, stringsAsFactors=FALSE)
    out$Domain <- Domain
    out$Value <- suppressWarnings(as.numeric(out$h))  # Value used for AAC
    out
  }

  # Stacked domains
  author_elements <- c(df[["PT"]], df[["LA"]])
  author_cit      <- c(citation, citation)

  country_elements <- c(df[["FAcountry"]], df[["Cacountry"]])
  country_cit      <- c(citation, citation)

  inst_elements <- c(df[["FAinstitute"]], df[["CAinstituteCoresp"]])
  inst_cit      <- c(citation, citation)

  dept_elements <- c(df[["FAdept"]], df[["Cadept "]])
  dept_elements <- stringr::str_replace(trimws(safestr(dept_elements)), "^(Dept|Department)\\s+", "")
  dept_cit      <- c(citation, citation)

  journal_elements <- df[["Journal ISO Abbreviation"]]
  journal_cit      <- citation

  year_elements <- df[["Publication Year"]]
  year_cit      <- citation

  doc_elements <- df[["Document Type"]]
  doc_cit      <- citation

  kp_cols <- intersect(paste0("A", 1:13), names(df))
  kp_elements <- character(0)
  if (length(kp_cols)){
    for (cc in kp_cols) kp_elements <- c(kp_elements, df[[cc]])
  }
  kp_cit <- rep(citation, times = max(1, length(kp_cols)))

  out <- rbind(
    summarise_domain("Country", country_elements, country_cit),
    summarise_domain("Institute", inst_elements, inst_cit),
    summarise_domain("Department", dept_elements, dept_cit),
    summarise_domain("Author", author_elements, author_cit),
    summarise_domain("Journal", journal_elements, journal_cit),
    summarise_domain("Year", year_elements, year_cit),
    summarise_domain("Document", doc_elements, doc_cit),
    summarise_domain("Keyword", kp_elements, kp_cit)
  )

  out <- out[, c("Domain","Element","n","h","Value")]
  out$Domain <- as.character(out$Domain)
  out$Element <- as.character(out$Element)
  out$n <- as.integer(out$n)
  out$h <- as.numeric(out$h)
  out$Value <- as.numeric(out$Value)

  # Apply Top 5 selection per domain; Year is chronological tail(5)
  res <- do.call(rbind, lapply(unique(out$Domain), function(dom){
    d <- out[out$Domain == dom, , drop=FALSE]
    if (!nrow(d)) return(d)
    if (dom == "Year") {
      d$y <- suppressWarnings(as.numeric(d$Element))
      d <- d[order(d$y), , drop=FALSE]
      d <- utils::tail(d, 5)
      d$y <- NULL
    } else {
      d <- d[order(-d$Value, -d$n, d$Element), , drop=FALSE]
      d <- utils::head(d, 5)
    }
    d
  }))
  rownames(res) <- NULL
  res
}
