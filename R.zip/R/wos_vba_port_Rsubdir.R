
.force_wos_fields <- function(df){
  if (is.null(df) || !is.data.frame(df) || nrow(df)==0) return(df)

  pick <- function(nm){
    if (nm %in% names(df)) df[[nm]] else NULL
  }

  if ("Publication Year" %in% names(df)) {
    df$year <- suppressWarnings(as.integer(df[["Publication Year"]]))
  }
  if ("Journal ISO Abbreviation" %in% names(df)) {
    df$journal <- as.character(df[["Journal ISO Abbreviation"]])
  }
  if ("Times Cited, WoS Core" %in% names(df)) {
    df$citation_raw <- as.character(df[["Times Cited, WoS Core"]])
  }

  if ("Authors" %in% names(df) && !("authors_raw" %in% names(df))) {
    df$authors_raw <- as.character(df[["Authors"]])
  }
  if ("Addresses" %in% names(df) && !("addresses_raw" %in% names(df))) {
    df$addresses_raw <- as.character(df[["Addresses"]])
  }
  if ("Research Areas" %in% names(df) && !("research_areas" %in% names(df))) {
    df$research_areas <- as.character(df[["Research Areas"]])
  }
  if ("Reprint Addresses" %in% names(df) && !("reprint_raw" %in% names(df))) {
    df$reprint_raw <- as.character(df[["Reprint Addresses"]])
  }
  if ("Keywords Plus" %in% names(df)) {
    # keep first two as keyword_plus_1/2 if not present
    if (!("keyword_plus_1" %in% names(df))) df$keyword_plus_1 <- as.character(df[["Keywords Plus"]])
    if (!("keyword_plus_2" %in% names(df))) df$keyword_plus_2 <- NA_character_
  }
  if ("Web of Science Index" %in% names(df)) {
    if (!("wos_index_1" %in% names(df))) df$wos_index_1 <- as.character(df[["Web of Science Index"]])
    if (!("wos_index_2" %in% names(df))) df$wos_index_2 <- NA_character_
  }
  if ("WoS Categories" %in% names(df) && !("wos_categories" %in% names(df))) {
    df$wos_categories <- as.character(df[["WoS Categories"]])
  }
  df
}

# R/wos_vba_port.R
# ------------------------------------------------------------
# WoS VBA -> R port (module)
# - Cmd13: relayout columns by Excel letters using a base column (default AG)
# - Cmd1: extract FA/CA + country/institute/department from WoS addresses/reprint
# - Cmd3: region via China city list + US state map
#
# Required files (relative to app root):
# - data/chinacity.xlsx  (only col1 used)
# - data/US.xlsx         (col1=abbr, col3=full state name; if no col3 then col2)
#
# Exported functions used by app.R:
# - wos_build_woslong()
# - wos_woslong_to_metadata_wide()
#
# Notes:
# - NO illegal escapes: all regex backslashes are doubled (\\s, \\b, etc.)
# - first_author() is vectorized (fixes "條件的長度 > 1")
# ------------------------------------------------------------

suppressPackageStartupMessages({
  library(dplyr)
  library(tidyr)
  library(stringr)
  library(rlang)
  library(tibble)
})

`%||%` <- function(a, b) if (!is.null(a) && length(a) && !all(is.na(a))) a else b

trim_na <- function(x){
  x <- ifelse(is.na(x), "", x)
  trimws(x)
}

# ---------- Lookup loaders ----------
load_lookup_tables <- function(
  chinacity_path = file.path("data", "chinacity.xlsx"),
  us_path        = file.path("data", "US.xlsx")
){
  if (!requireNamespace("readxl", quietly = TRUE)) {
    stop("Package 'readxl' is required to read chinacity.xlsx / US.xlsx.")
  }

  chinacity <- NULL
  us <- NULL

  if (file.exists(chinacity_path)) {
    chinacity <- readxl::read_excel(chinacity_path, .name_repair = "minimal") %>% as.data.frame()
  }
  if (file.exists(us_path)) {
    us <- readxl::read_excel(us_path, .name_repair = "minimal") %>% as.data.frame()
  }

  list(chinacity = chinacity, us = us)
}

# ---------- Excel column helpers ----------
excel_col_to_index <- function(col_letter){
  x <- toupper(trimws(col_letter))
  if (!nzchar(x)) return(NA_integer_)
  chars <- strsplit(x, "")[[1]]
  n <- 0
  for (ch in chars){
    n <- n * 26 + (utf8ToInt(ch) - utf8ToInt("A") + 1)
  }
  n
}

excel_index_to_col_letter <- function(idx){
  idx <- as.integer(idx)
  if (is.na(idx) || idx < 1) return(NA_character_)
  out <- ""
  while (idx > 0){
    r <- (idx - 1) %% 26
    out <- paste0(LETTERS[r + 1], out)
    idx <- (idx - 1) %/% 26
  }
  out
}

pick_excel_col <- function(df, col_letter, base_col = "A"){
  idx <- excel_col_to_index(col_letter)
  base_idx <- excel_col_to_index(base_col)
  adj <- idx - base_idx + 1
  if (is.na(adj) || adj < 1 || adj > ncol(df)) return(NULL)
  df[[adj]]
}

# ---------- Cmd13 relayout ----------
wos_cmd13_relayout <- function(df, base_col = "AG"){
  n <- nrow(df)
  as_vec <- function(x) if (is.null(x)) rep("", n) else x

  # Mapping per your VBA intent (BN/CA/BY/AH/AL/CR/BC/BE/AZ/BA/AP/CP)
  citation_raw   <- pick_excel_col(df, "BN", base_col = base_col)
  journal        <- pick_excel_col(df, "CA", base_col = base_col)
  year           <- pick_excel_col(df, "BY", base_col = base_col)
  authors_raw    <- pick_excel_col(df, "AH", base_col = base_col)
  addresses_raw  <- pick_excel_col(df, "AL", base_col = base_col)
  research_areas <- pick_excel_col(df, "CR", base_col = base_col)
  wos_index_1    <- pick_excel_col(df, "BC", base_col = base_col)
  wos_index_2    <- pick_excel_col(df, "BE", base_col = base_col)
  keyword_plus_1 <- pick_excel_col(df, "AZ", base_col = base_col)
  keyword_plus_2 <- pick_excel_col(df, "BA", base_col = base_col)
  reprint_raw    <- pick_excel_col(df, "AP", base_col = base_col)
  wos_categories <- pick_excel_col(df, "CP", base_col = base_col)

  tibble(
    citation_raw   = as_vec(citation_raw),
    journal        = as_vec(journal),
    year           = as_vec(year),
    authors_raw    = as_vec(authors_raw),
    addresses_raw  = as_vec(addresses_raw),
    research_areas = as_vec(research_areas),
    wos_index_1    = as_vec(wos_index_1),
    wos_index_2    = as_vec(wos_index_2),
    keyword_plus_1 = as_vec(keyword_plus_1),
    keyword_plus_2 = as_vec(keyword_plus_2),
    reprint_raw    = as_vec(reprint_raw),
    wos_categories = as_vec(wos_categories)
  ) %>% mutate(across(everything(), trim_na))
}

# ---------- shared cleaning ----------
clean_wos_text <- function(x){
  x <- trim_na(x)
  if (!nzchar(x)) return(x)

  x <- str_replace_all(x, ",\\s*Affiliated Hosp", "-Affiliated Hosp")
  x <- str_replace_all(x, ",Affiliated Hosp", "-Affiliated Hosp")

  x <- str_replace_all(x, "UNIV\\s+", "Univ ")
  x <- str_replace_all(x, "SCH\\s+",  "Sch ")
  x <- str_replace_all(x, "COLL\\s+", "Coll ")
  x <- str_replace_all(x, "DIS\\s+",  "Dis ")
  x <- str_replace_all(x, "DIV\\s+",  "Div ")
  x <- str_replace_all(x, "CRT\\s+",  "Crt ")
  x <- str_replace_all(x, "HOSP\\s+", "Hosp ")
  x <- str_replace_all(x, "SINICA\\s+", "Scinica ")

  x <- str_replace_all(x, "Gynaecol", "Gynecol")
  x <- str_replace_all(x, "Paediatrics", "Pediatrics")
  x <- str_replace_all(x, "，", "")
  x
}

# ---------- country ----------
norm_country <- function(x){
  x <- clean_wos_text(x)
  if (!nzchar(x)) return("")

  if (str_detect(x, fixed("Hong Kong"))) return("Hong Kong")
  if (str_detect(x, fixed("Taiwan"))) return("Taiwan")
  if (str_detect(x, fixed("China")) && !str_detect(x, fixed("Hong Kong")) && !str_detect(x, fixed("Taiwan"))) return("China")

  toks <- str_split(x, ",")[[1]] %>% trimws()
  country <- toks[length(toks)]
  country <- str_replace_all(country, "\\.", "")

  if (str_detect(country, fixed("USA"))) country <- "U.S"
  if (str_detect(country, "North(ern)?\\s+Ireland|England|Scotland|Wales|London")) country <- "U.K"
  if (str_detect(country, fixed("Fed Rep Ger"))) country <- "Germany"
  country
}

# ---------- Cmd3 region ----------
extract_region <- function(addresses_text, chinacity = NULL, us = NULL){
  x <- clean_wos_text(addresses_text)
  if (!nzchar(x)) return("")

  if (str_detect(x, fixed("Hong Kong"))) return("Hong Kong")
  if (str_detect(x, fixed("Taiwan"))) return("Taiwan")

  # China (excluding HK/TW): match chinacity col1 entry if found; otherwise "China"
  if (str_detect(x, fixed("China")) && !str_detect(x, fixed("Hong Kong")) && !str_detect(x, fixed("Taiwan"))) {
    if (!is.null(chinacity) && nrow(chinacity) > 0) {
      city_col <- names(chinacity)[1]
      vals <- trim_na(as.character(chinacity[[city_col]]))
      vals <- vals[vals != ""]
      for (v in vals) {
        if (v %in% c("Taiwan", "Hong Kong")) next
        if (str_detect(x, fixed(v))) return(v)
      }
    }
    return("China")
  }

  # USA: match 2-letter abbr as word boundary; return full name
  if (str_detect(x, fixed("USA"))) {
    if (!is.null(us) && nrow(us) > 0) {
      abbr <- trim_na(as.character(us[[1]]))
      region <- if (ncol(us) >= 3) trim_na(as.character(us[[3]])) else trim_na(as.character(us[[2]]))
      for (i in seq_along(abbr)) {
        ab <- abbr[i]
        if (nchar(ab) == 2 && str_detect(x, regex(paste0("\\b", ab, "\\b")))) return(region[i])
      }
      return("U.S")
    }
    return("U.S")
  }

  ""
}

# ---------- institute/department heuristics ----------
pick_institute <- function(tokens){
  tokens <- trim_na(tokens); tokens <- tokens[tokens != ""]
  if (!length(tokens)) return("")
  hit <- tokens[str_detect(tokens, " Sinica| Inst|Coll\\s|Syst|Hlth|Mayo Clin|Hosp|Univ|Ctr| Med")]
  if (length(hit)) return(hit[1])
  tokens[1]
}

pick_department <- function(tokens){
  tokens <- trim_na(tokens); tokens <- tokens[tokens != ""]
  if (!length(tokens)) return("")
  hit <- tokens[str_detect(tokens, "Coll Med|Inst\\s|Sch\\s|Coll\\s|Dis\\s|Div\\s|Dept\\s|Ctr\\s|Res Ctr|Med Ctr|\\sCtr")]
  dept <- if (length(hit)) hit[1] else ""
  dept <- str_replace_all(dept, "^Dept\\s+", "")
  dept <- str_replace_all(dept, "^Div\\s+",  "")
  dept <- str_replace_all(dept, "^Dis\\s+",  "")
  dept <- str_replace_all(dept, "^Ctr\\s+",  "")
  dept <- str_replace_all(dept, "^Sch\\s+",  "")
  dept <- str_replace_all(dept, "\\s+Inst\\b", "")
  trim_na(dept)
}

# ---------- author block picking ----------
norm_author_key <- function(x){
  x <- trim_na(x)
  x <- str_to_lower(x)
  x <- str_replace_all(x, "[^a-z\\s]", " ")
  str_squish(x)
}

pick_block_for_author <- function(addresses, author_name){
  addresses <- clean_wos_text(addresses)
  if (!nzchar(addresses)) return("")
  parts <- str_split(addresses, "\\s*;\\s*")[[1]] %>% trim_na()
  parts <- parts[parts != ""]
  if (!length(parts)) return("")
  if (!nzchar(trim_na(author_name))) return(parts[1])

  key <- norm_author_key(author_name)
  surname <- str_split(key, "\\s+")[[1]][1]
  if (!nzchar(surname)) return(parts[1])

  hit <- parts[str_detect(norm_author_key(parts), regex(paste0("\\b", surname, "\\b")))]
  if (length(hit)) hit[1] else parts[1]
}

strip_author_bracket <- function(block){
  b <- block
  # Typical WoS tag: "[Surname, Given] ...". Sometimes brackets are broken
  # (e.g., "[Cheng"), so we defensively remove any leading bracket-tag.
  if (str_detect(b, "\\]\\s")) {
    b <- str_split(b, "\\]\\s")[[1]]
    b <- b[length(b)]
  }
  b <- str_replace(b, "^\\[[^\\]]*\\]\\s*", "")  # well-formed [..]
  b <- str_replace(b, "^\\[[^,;]*\\s*", "")       # broken "[Cheng" style
  trim_na(b)
}

parse_affiliation_block <- function(block, full_addresses, chinacity = NULL, us = NULL){
  block <- clean_wos_text(block)
  if (!nzchar(block)) return(list(country="", region="", institute="", department=""))

  core <- strip_author_bracket(block)
  toks <- str_split(core, "\\s*,\\s*")[[1]] %>% trim_na()
  toks <- toks[toks != ""]

  # If the block still begins with an author name split by comma
  # (e.g., "Li, Meng-Ju, Natl Taiwan Univ ..."), drop the first 1-2 name tokens.
  if (length(toks) >= 2) {
    if (grepl("^[A-Za-z]+$", toks[1]) && grepl("^[A-Za-z-]+$", toks[2])) {
      toks <- toks[-c(1,2)]
    } else if (grepl("^[A-Za-z]+$", toks[1]) && grepl("^[A-Z]{1,3}$", toks[2])) {
      toks <- toks[-c(1,2)]
    }
  }

  inst <- pick_institute(toks)
  dept <- pick_department(toks)
  country <- norm_country(core)
  region <- extract_region(full_addresses %||% core, chinacity = chinacity, us = us)

  # cleanup per your requirements
  inst <- str_replace(inst, "^.*\\]\\s*", "")
  region <- str_replace(region, "^CN-", "")
  dept <- str_replace(dept, "^Dept\\s+", "")

  list(country=country, region=region, institute=inst, department=dept)
}

# Pick the best affiliation meta for an author when multiple address blocks match.
# Prefer the FIRST matching block that yields a non-empty department; otherwise
# fall back to the first match.
pick_meta_for_author <- function(addresses, author_name, chinacity = NULL, us = NULL){
  addresses <- clean_wos_text(addresses)
  if (!nzchar(addresses)) return(list(country="", region="", institute="", department=""))

  parts <- str_split(addresses, "\\s*;\\s*")[[1]] %>% trim_na()
  parts <- parts[parts != ""]
  if (!length(parts)) return(list(country="", region="", institute="", department=""))

  if (!nzchar(trim_na(author_name))) {
    return(parse_affiliation_block(parts[1], addresses, chinacity, us))
  }

  key <- norm_author_key(author_name)
  surname <- str_split(key, "\\s+")[[1]][1]
  if (!nzchar(surname)) {
    return(parse_affiliation_block(parts[1], addresses, chinacity, us))
  }

  hits <- parts[str_detect(norm_author_key(parts), regex(paste0("\\b", surname, "\\b")))]
  if (!length(hits)) hits <- parts[1]

  for (h in hits) {
    meta <- parse_affiliation_block(h, addresses, chinacity, us)
    if (nzchar(trim_na(meta$department))) return(meta)
  }
  parse_affiliation_block(hits[1], addresses, chinacity, us)
}

# ---------- FA / CA (VECTORIZED) ----------
first_author <- function(authors_raw){
  a <- trim_na(authors_raw)
  vapply(a, function(x){
    x <- trim_na(x)
    if (!nzchar(x)) return("")
    parts <- str_split(x, "\\s*;\\s*")[[1]] %>% trim_na()
    parts <- parts[parts != ""]
    if (!length(parts)) "" else parts[1]
  }, FUN.VALUE = character(1))
}

guess_ca_from_reprint <- function(reprint_raw, authors_raw){
  mapply(function(rp, ar){
    rp <- trim_na(rp)
    ar <- trim_na(ar)

    parts <- str_split(ar, "\\s*;\\s*")[[1]] %>% trim_na()
    parts <- parts[parts != ""]
    lastA <- if (!length(parts)) "" else parts[length(parts)]

    if (!nzchar(rp)) return(lastA)

    cand <- rp
    cand <- str_replace(cand, "^.*?(Corresponding Author:|Reprint Address:)", "")
    cand <- trim_na(cand)
    cand <- str_split(cand, "\\(")[[1]][1]
    cand <- trim_na(cand)

    if (!nzchar(cand)) lastA else cand
  }, reprint_raw, authors_raw, USE.NAMES = FALSE)
}

wos_add_fa_ca_meta <- function(df, chinacity = NULL, us = NULL){
  df <- df %>% mutate(
    FA = first_author(authors_raw),
    CA = guess_ca_from_reprint(reprint_raw, authors_raw)
  )

  # Handle multiple matching blocks per author (common in WoS C1)
  fa_meta <- lapply(seq_len(nrow(df)), function(i)
    pick_meta_for_author(df$addresses_raw[i], df$FA[i], chinacity, us)
  )
  ca_meta <- lapply(seq_len(nrow(df)), function(i)
    pick_meta_for_author(df$addresses_raw[i], df$CA[i], chinacity, us)
  )

  df$FA_country    <- vapply(fa_meta, `[[`, "", "country")
  df$FA_region     <- vapply(fa_meta, `[[`, "", "region")
  df$FA_institute  <- vapply(fa_meta, `[[`, "", "institute")
  df$FA_dept       <- vapply(fa_meta, `[[`, "", "department")

  df$CA_country    <- vapply(ca_meta, `[[`, "", "country")
  df$CA_region     <- vapply(ca_meta, `[[`, "", "region")
  df$CA_institute  <- vapply(ca_meta, `[[`, "", "institute")
  df$CA_dept       <- vapply(ca_meta, `[[`, "", "department")

  df
}

# ---------- two disciplines ----------
extract_two_disciplines <- function(wos_categories, wos_index_1, wos_index_2, research_areas){
  x <- paste(trim_na(wos_categories), trim_na(wos_index_1), trim_na(wos_index_2), trim_na(research_areas), sep=";")
  toks <- str_split(x, "\\s*;\\s*")[[1]] %>% trim_na()
  toks <- toks[toks != ""]
  toks <- unique(toks)
  if (length(toks) == 0) return(c("", ""))
  if (length(toks) == 1) return(c(toks[1], ""))
  c(toks[1], toks[2])
}

# ---------- keyword plus wide ----------
keyword_plus_to_wide <- function(df,
                                 keyword_cols = c("keyword_plus_1","keyword_plus_2"),
                                 prefix = "keyword__"){
  kp <- df %>%
    transmute(
      .row_id = row_number(),
      .kp = paste(!!!rlang::syms(keyword_cols), sep=";")
    ) %>%
    mutate(.kp = trim_na(.kp)) %>%
    mutate(.kp = str_replace_all(.kp, "\\s*;+\\s*", ";")) %>%
    mutate(.kp = str_replace_all(.kp, "^;+|;+$", ""))

  long <- kp %>%
    separate_rows(.kp, sep="\\s*;\\s*") %>%
    mutate(.kp = trim_na(.kp)) %>%
    filter(.kp != "")

  if (nrow(long) == 0) return(df)

  wide <- long %>%
    mutate(col = paste0(prefix, make.names(toupper(.kp)))) %>%
    distinct(.row_id, col) %>%
    mutate(value = 1L) %>%
    pivot_wider(names_from = col, values_from = value, values_fill = 0L)

  df %>%
    mutate(.row_id = row_number()) %>%
    left_join(wide, by = ".row_id") %>%
    select(-.row_id)
}

# ---------- base column guessing (optional) ----------
scan_best_base_col <- function(df, default_base = "AG", window = 10){
  nms_l <- tolower(names(df))

  anchors <- list(
    list(letter="BY", p="^publication\\s*year$"),
    list(letter="AH", p="^authors$"),
    list(letter="AL", p="^addresses$"),
    list(letter="AP", p="^reprint\\s*addresses$"),
    list(letter="AZ", p="^keywords\\s*plus$"),
    list(letter="CR", p="^research\\s*areas$"),
    list(letter="CP", p="^wos\\s*categories$|^web\\s*of\\s*science\\s*categories$"),
    list(letter="CA", p="^source\\s*title$|^journal\\s*iso\\s*abbreviation$"),
    list(letter="BN", p="^pubmed\\s*id$|^ut\\s*\\(unique\\s*wos\\s*id\\)$")
  )

  base0 <- excel_col_to_index(default_base)
  cand_idx <- seq(max(1, base0 - window), base0 + window)

  score_one <- function(base_idx){
    sc <- 0
    for (a in anchors){
      target_idx <- excel_col_to_index(a$letter) - base_idx + 1
      if (target_idx >= 1 && target_idx <= length(nms_l)){
        if (grepl(a$p, nms_l[target_idx], perl = TRUE)) sc <- sc + 1
      }
    }
    sc
  }

  scores <- vapply(cand_idx, score_one, numeric(1))
  best_idx <- cand_idx[which.max(scores)]
# If headers are uninformative (e.g., X__1 style), fall back to content-based scoring.
if (max(scores, na.rm = TRUE) <= 0) {
  # sample a few rows to score likely columns
  n <- nrow(df)
  take <- seq_len(min(n, 50))
  get_col <- function(letter, base_idx){
    adj <- excel_col_to_index(letter) - base_idx + 1
    if (is.na(adj) || adj < 1 || adj > ncol(df)) return(NULL)
    as.character(df[[adj]][take])
  }

  year_score <- function(v){
    v <- trimws(v)
    mean(grepl("^(19|20)\\d{2}$", v), na.rm = TRUE)
  }
  semi_score <- function(v){
    v <- trimws(v)
    mean(grepl(";", v, fixed = TRUE), na.rm = TRUE)
  }
  addr_score <- function(v){
    v <- trimws(v)
    mean(grepl("\\[|Univ|Hosp|Dept|Taiwan|China|USA|School|Inst", v, perl = TRUE), na.rm = TRUE)
  }
  text_score <- function(v){
    v <- trimws(v)
    mean(grepl("[A-Za-z]", v), na.rm = TRUE)
  }
  num_score <- function(v){
    v <- trimws(v)
    mean(grepl("^\\d+$", v), na.rm = TRUE)
  }

  score_content_one <- function(base_idx){
    by <- get_col("BY", base_idx)
    ah <- get_col("AH", base_idx)
    al <- get_col("AL", base_idx)
    ca <- get_col("CA", base_idx)
    az <- get_col("AZ", base_idx)
    bn <- get_col("BN", base_idx)
    sc <- 0
    if (!is.null(by)) sc <- sc + 3 * year_score(by)
    if (!is.null(ah)) sc <- sc + 2 * semi_score(ah)
    if (!is.null(al)) sc <- sc + 2 * addr_score(al)
    if (!is.null(ca)) sc <- sc + 1 * text_score(ca) - 2 * year_score(ca)
    if (!is.null(az)) sc <- sc + 1 * semi_score(az)
    if (!is.null(bn)) sc <- sc + 0.5 * num_score(bn)
    sc
  }

  cs <- vapply(cand_idx, score_content_one, numeric(1))
  best2 <- cand_idx[which.max(cs)]
  if (max(cs, na.rm = TRUE) <= 0) return(default_base)
  return(excel_index_to_col_letter(best2))
}

excel_index_to_col_letter(best_idx)
}

# -------------------------
# Exported: build woslong
# -------------------------
wos_build_woslong <- function(raw_df, chinacity = NULL, us = NULL,
                              chinacity_path = file.path("data","chinacity.xlsx"),
                              us_path = file.path("data","US.xlsx"),
                              default_base = "AG",
                              strict_base = TRUE){

  if (is.null(chinacity) || is.null(us)){
    lk <- load_lookup_tables(chinacity_path = chinacity_path, us_path = us_path)
    chinacity <- chinacity %||% lk$chinacity
    us        <- us %||% lk$us
  }

  base_col <- if (isTRUE(strict_base)) default_base else scan_best_base_col(raw_df, default_base = default_base, window = 10)

  rel <- wos_cmd13_relayout(raw_df, base_col = base_col)
  rel <- wos_add_fa_ca_meta(rel, chinacity = chinacity, us = us)

  disc <- t(mapply(extract_two_disciplines,
                   rel$wos_categories, rel$wos_index_1, rel$wos_index_2, rel$research_areas))
  rel$discipline_1 <- trim_na(disc[,1])
  rel$discipline_2 <- trim_na(disc[,2])

  attr(rel, "base_col") <- base_col
  rel
}

# -------------------------
# Exported: final wide output
# -------------------------
wos_woslong_to_metadata_wide <- function(woslong_df){
  if (is.null(woslong_df) || !is.data.frame(woslong_df) || nrow(woslong_df) == 0){
    return(data.frame())
  }


  # Ensure citation_raw exists (prevents parse-time confusion if upstream changes column names)
  if (!("citation_raw" %in% names(woslong_df))) {
    woslong_df$citation_raw <- NA_character_
  }

  out <- woslong_df %>%
    transmute(
     citation     = dplyr::if_else(trim_na(as.character(citation_raw)) == "", as.character(dplyr::row_number()), as.character(citation_raw)),
      journal      = as.character(journal),
      Document   = dplyr::coalesce(as.character(.data$Document), as.character(.data$document), as.character(.data$DOC), as.character(.data$`Document Type`), as.character(.data$doctype), ""),
      year         = as.character(year),
      FA           = as.character(FA),
      CA           = as.character(CA),
      FA_country   = as.character(FA_country),
      CA_country   = as.character(CA_country),
      FA_institute = as.character(FA_institute),
      CA_institute = as.character(CA_institute),
      FA_dept      = as.character(FA_dept),
      CA_dept      = as.character(CA_dept),
      FA_region    = as.character(FA_region),
      CA_region    = as.character(CA_region),
      discipline_1 = as.character(discipline_1),
      discipline_2 = as.character(discipline_2),
      keyword_plus_1 = as.character(keyword_plus_1),
      keyword_plus_2 = as.character(keyword_plus_2)
    )

  # Final safety cleanup + paired fill (FA/CA): remove stray bracket fragments and
  # coalesce missing values using the paired side.
  strip_bracket_frag <- function(x){
    x <- trim_na(x)
    x <- str_replace_all(x, "\\[|\\]", "")
    x <- trim_na(x)
    ifelse(is.na(x), "", x)
  }
  for (cc in intersect(c("FA_institute","CA_institute","FA_dept","CA_dept","FA_country","CA_country","FA_region","CA_region"), names(out))) {
    out[[cc]] <- strip_bracket_frag(out[[cc]])
  }
  if (all(c("FA_dept","CA_dept") %in% names(out))) {
    out$CA_dept <- dplyr::coalesce(dplyr::na_if(out$CA_dept, ""), dplyr::na_if(out$FA_dept, "")) %>% tidyr::replace_na("")
    out$FA_dept <- dplyr::coalesce(dplyr::na_if(out$FA_dept, ""), dplyr::na_if(out$CA_dept, "")) %>% tidyr::replace_na("")
  }
  if (all(c("FA_institute","CA_institute") %in% names(out))) {
    out$CA_institute <- dplyr::coalesce(dplyr::na_if(out$CA_institute, ""), dplyr::na_if(out$FA_institute, "")) %>% tidyr::replace_na("")
    out$FA_institute <- dplyr::coalesce(dplyr::na_if(out$FA_institute, ""), dplyr::na_if(out$CA_institute, "")) %>% tidyr::replace_na("")
  }
  if (all(c("FA_country","CA_country") %in% names(out))) {
    out$CA_country <- dplyr::coalesce(dplyr::na_if(out$CA_country, ""), dplyr::na_if(out$FA_country, "")) %>% tidyr::replace_na("")
    out$FA_country <- dplyr::coalesce(dplyr::na_if(out$FA_country, ""), dplyr::na_if(out$CA_country, "")) %>% tidyr::replace_na("")
  }
  if (all(c("FA_region","CA_region") %in% names(out))) {
    out$CA_region <- dplyr::coalesce(dplyr::na_if(out$CA_region, ""), dplyr::na_if(out$FA_region, "")) %>% tidyr::replace_na("")
    out$FA_region <- dplyr::coalesce(dplyr::na_if(out$FA_region, ""), dplyr::na_if(out$CA_region, "")) %>% tidyr::replace_na("")
  }

  out2 <- keyword_plus_to_wide(out, keyword_cols = c("keyword_plus_1","keyword_plus_2"), prefix = "keyword__")
  out2 %>% select(-keyword_plus_1, -keyword_plus_2)
}
